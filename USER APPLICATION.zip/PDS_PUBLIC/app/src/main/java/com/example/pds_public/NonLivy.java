package com.example.pds_public;

import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

public class NonLivy extends AppCompatActivity {

    private EditText textView2, textView4, textView6, textView8, textView10, textView12, textView14, textView16;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_non_livy);

        textView2 = findViewById(R.id.textView2);
        textView4 = findViewById(R.id.textView4);
        textView6 = findViewById(R.id.textView6);
        textView8 = findViewById(R.id.textView8);
        textView10 = findViewById(R.id.textView10);
        textView12 = findViewById(R.id.textView12);
        textView14 = findViewById(R.id.textView14);
        textView16 = findViewById(R.id.textView16);

        Button submitButton = findViewById(R.id.button);
        submitButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                // Get data from EditTexts
                String data2 = textView2.getText().toString();
                String data4 = textView4.getText().toString();
                String data6 = textView6.getText().toString();
                String data8 = textView8.getText().toString();
                String data10 = textView10.getText().toString();
                String data12 = textView12.getText().toString();
                String data14 = textView14.getText().toString();
                String data16 = textView16.getText().toString();

                // Retrieve user email from SharedPreferences
                SharedPreferences preferences = getSharedPreferences("User", MODE_PRIVATE);
                String userEmail = preferences.getString("userEmail", "");

                // Fetch ShopNumber based on Email and upload data
                fetchShopNumberAndUploadData(userEmail, data2, data4, data6, data8, data10, data12, data14, data16);

                // Optionally, add a success message or handle next steps

                // Finish the Activity2 if needed
                // finish();
            }
        });
    }

    private void fetchShopNumberAndUploadData(final String userEmail, final String data2, final String data4, final String data6, final String data8, final String data10, final String data12, final String data14, final String data16) {
        // Reference to the "users" node
        DatabaseReference usersReference = FirebaseDatabase.getInstance().getReference("users");

        usersReference.orderByChild("email").equalTo(userEmail).addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot dataSnapshot) {
                if (dataSnapshot.exists()) {
                    // Get the user node
                    DataSnapshot userSnapshot = dataSnapshot.getChildren().iterator().next();

                    // Get the user's name
                    String userName = userSnapshot.child("name").getValue(String.class);

                    if (userName != null && !userName.isEmpty()) {
                        // Fetch ShopNumber based on Name
                        DatabaseReference shopDetailsReference = FirebaseDatabase.getInstance().getReference("ShopDetails");
                        shopDetailsReference.orderByChild("shopNumber").equalTo(userName).addListenerForSingleValueEvent(new ValueEventListener() {
                            @Override
                            public void onDataChange(DataSnapshot dataSnapshot) {
                                if (dataSnapshot.exists()) {
                                    // Get the first matching shop
                                    DataSnapshot shopSnapshot = dataSnapshot.getChildren().iterator().next();

                                    // Get ShopNumber from the shop
                                    String shopNumber = shopSnapshot.child("shopNumber").getValue(String.class);

                                    if (shopNumber != null && !shopNumber.isEmpty()) {
                                        // Upload data to Firebase Database
                                        uploadDataToFirebase(shopNumber, data2, data4, data6, data8, data10, data12, data14, data16);
                                    } else {
                                        showToast("ShopNumber not found for " + userName);
                                    }
                                } else {
                                    showToast("Shop not found for " + userName);
                                }
                            }

                            @Override
                            public void onCancelled(DatabaseError databaseError) {
                                showToast("Database error: " + databaseError.getMessage());
                            }
                        });
                    } else {
                        showToast("Name not found for " + userEmail);
                    }
                } else {
                    showToast("User not found for " + userEmail);
                }
            }

            @Override
            public void onCancelled(DatabaseError databaseError) {
                showToast("Database error: " + databaseError.getMessage());
            }
        });
    }

    private void uploadDataToFirebase(String shopNumber, String data2, String data4, String data6, String data8, String data10, String data12, String data14, String data16) {
        // Upload data to the "NonLivy" node with shopNumber as the key
        DatabaseReference nonLivyReference = FirebaseDatabase.getInstance().getReference("ShopDetails").child(shopNumber);

        nonLivyReference.child("RICE FLOUR").setValue(data2+"in pcs");
        nonLivyReference.child("WHEAT FLOUR").setValue(data4);
        nonLivyReference.child("MAIDA FLOUR").setValue(data6);
        nonLivyReference.child("SOAP").setValue(data8);
        nonLivyReference.child("MATCH BOX").setValue(data10);
        nonLivyReference.child("TEA").setValue(data12);
        nonLivyReference.child("SOOJI").setValue(data14);
        nonLivyReference.child("SALT").setValue(data16);
    }

    private void showToast(String message) {
        // A helper method to show toast messages
        Toast.makeText(this, message, Toast.LENGTH_SHORT).show();
    }
}