package com.example.pds_public;

import android.app.DownloadManager;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.text.method.LinkMovementMethod;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;
import androidx.cardview.widget.CardView;

public class query extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_query);

        LinearLayout faqContainer = findViewById(R.id.faq_container);

        // Add questions and answers dynamically
        addQuestionAndAnswer(faqContainer, "Q1: Can a single person apply for a ration card ?", "A1: Yes, a single person whose is living alone for atleast one year separately in a residence can apply for a family card. He/She should satisfy all the documentary requirements as stated in the section on new family card applications.\n" +
                "\n" +
                "Sons or daughters, married or otherwise, living with their parents are NOT eligible for a separate family card.");

        addQuestionAndAnswer(faqContainer, "Q2: Can a transgender person apply for a family card ?", "A2:Yes, a transgender person is fully eligible to apply for a card for his/her family just like any other person. The same rules apply.");

        // Third FAQ with downloadable document (changed to Q3)
        addQuestionAndAnswer(faqContainer, "Q3: What are the rates of foodgrains distributed ?", "", "Document.pdf");

        addQuestionAndAnswer(faqContainer, "Q4: Which modes are available to make the payment?", "A4:Yes, a transgender person is fully eligible to apply for a card for his/her family just like any other person. The same rules apply.");
        addQuestionAndAnswer(faqContainer, "Q5: How one can get a Ration Card?", "A5:First, visit the respective ration shop.\n" +
                "From the shop, collect the application form.\n" +
                "You can also download it online.\n" +
                "Fill up the application form.\n" +
                "Attach all the asked documents.\n" +
                "Submit the form at the concerned department\n" +
                "A reference number will be generated.\n" +
                "Keep safe for future use.");
        addQuestionAndAnswer(faqContainer, "Q6: What is e Ration Card?", "A6:e-ration card is a seamless facility provided by several state governments for households to obtain a ration card. E-ration was first introduced in Delhi and has gradually covered states such as Tamil Nadu and Karnataka. Only aadhaar cardholders can apply using e-ration card facility.");
        addQuestionAndAnswer(faqContainer, "Q7: Who are eligible for e Ration Card?", "A7:The applicant must be a citizen of India.\n" +
                "The family of the applicant should also be Indian citizens.\n" +
                "The family and the applicant should live and cook separately.\n" +
                "The applicant and his/her family need to be residents of Tamil Nadu.\n" +
                "The applicant and his/her family should not be in possession of family card not registered in any other Indian state.\n" +
                "The applicant and his/her family should not have their names enrolled as members in another family card.\n" +
                "The applicant and family members should be close relatives.");
        addQuestionAndAnswer(faqContainer, "Q8: How to download e Ration Card Pdf?", "A8:i. The applicant may submit his online Application.\n" +
                "ii. He has to visit website of the Food & Supplies Department www.food.wb.gov.in and Click “Services” Menu and Click Tab “Ration Card” and select link for applying for new Ration Card as per requirement.\n" +
                "iii. He will be guided to “Apply for Digital Ration Card”.\n" +
                "iv. He has to complete the online Application and submit.\n" +
                "v. Application is approved as per due process.\n" +
                "vi. On approval of his application, the applicant receives a SMS intimating approval of eRation Card in the same mobile number. The SMS also contains a link to download eRation Card as pdf file.\n" +
                "vii. Applicant can download the e-RC of all family members in PDF format.\n" +
                "viii. Additionally, after approval of the e-Ration Card, the applicant can login in the website. www.food.wb.gov.in through OTP received on his RMN and access his dashboard and view the e-RCs of his family members any time.Details of all members of the family are shown, and e-RCs can be downloaded.");
        addQuestionAndAnswer(faqContainer, "Q9: What are the documents are required while applying for the digital ration card in Tamilnadu", "A9:The following documents are required while applying for the digital ration card in Tamilnadu:-\n" +
                "\n" +
                "Aadhar Card\n" +
                "Pan Card\n" +
                "Recent Size Photography Pass\n" +
                "Bank passbook\n" +
                "Caste/Category certificate\n" +
                "Income certificate\n" +
                "Electricity bill\n" +
                "TNPDS Ration Card Online Application Form\n");
        addQuestionAndAnswer(faqContainer, "Q10: What is the system of Inspection and Checking of Fair Price Shops ? ", "A10:Fair Price Shops have to maintain prescribed sales records/ registers, stock registers and family card registers.\n" +
                "\n" +
                "Collectors/Deputy Commissioners (Chennai) ensure inspection of Fair Price Shop of not less than once in one month by designated authorities.\n" +
                "\n");

        // Add more questions and answers as needed
    }

    private void addQuestionAndAnswer(ViewGroup container, String question, String answer) {
        addQuestionAndAnswer(container, question, answer, false, null);
    }

    private void addQuestionAndAnswer(ViewGroup container, String question, String answer, String documentName) {
        addQuestionAndAnswer(container, question, answer, true, documentName);
    }

    private void addQuestionAndAnswer(ViewGroup container, String question, String answer, boolean hasDownloadButton, final String documentName) {
        // Create CardView
        CardView cardView = new CardView(this);
        LinearLayout.LayoutParams cardParams = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT
        );
        cardParams.setMargins(0, 50, 0, 16); // Add margin bottom for spacing
        cardView.setLayoutParams(cardParams);
        cardView.setCardElevation(8); // Elevation for shadow effect
        cardView.setRadius(8); // Corner radius for rounded corners
        container.addView(cardView);

        // Create LinearLayout inside CardView
        LinearLayout innerLayout = new LinearLayout(this);
        innerLayout.setLayoutParams(new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT
        ));
        innerLayout.setOrientation(LinearLayout.HORIZONTAL);
        cardView.addView(innerLayout);

        // Create question TextView
        // Create question TextView
        final TextView questionTextView = new TextView(this);
        LinearLayout.LayoutParams questionParams = new LinearLayout.LayoutParams(
                0,
                ViewGroup.LayoutParams.WRAP_CONTENT,
                1
        );
        questionParams.setMargins(16, 16, 0, 16); // Add margin for spacing
        questionTextView.setLayoutParams(questionParams);
        questionTextView.setText(question);
        questionTextView.setTextColor(getResources().getColor(android.R.color.black));
        questionTextView.setTextSize(20); // Increased font size to 20
        questionTextView.setMovementMethod(LinkMovementMethod.getInstance()); // Make URL clickable
        questionTextView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (questionTextView.getText().toString().contains("www.food.wb.gov.in")) {
                    Intent browserIntent = new Intent(Intent.ACTION_VIEW, Uri.parse("http://www.food.wb.gov.in"));
                    startActivity(browserIntent);
                }
            }
        });
        innerLayout.addView(questionTextView);


        // Create ImageView for expand/collapse icon
        final ImageView expandCollapseIcon = new ImageView(this);
        LinearLayout.LayoutParams iconParams = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT,
                ViewGroup.LayoutParams.WRAP_CONTENT
        );
        iconParams.setMargins(0, 16, 16, 16); // Add margin for spacing
        expandCollapseIcon.setLayoutParams(iconParams);
        expandCollapseIcon.setImageResource(R.drawable.ic_expand_more); // Initial state: expand icon
        innerLayout.addView(expandCollapseIcon);

        // Create answer TextView (Initially invisible)
        final TextView answerTextView = new TextView(this);
        LinearLayout.LayoutParams answerParams = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT
        );
        answerParams.setMargins(16, 0, 16, 16); // Add margin for spacing
        answerTextView.setLayoutParams(answerParams);
        answerTextView.setText(answer);
        answerTextView.setTextColor(getResources().getColor(android.R.color.black));
        answerTextView.setTextSize(20); // Increased font size to 18
        answerTextView.setVisibility(View.GONE);
        container.addView(answerTextView);

        if (hasDownloadButton) {
            // Create download Button
            final Button downloadButton = new Button(this);
            LinearLayout.LayoutParams buttonParams = new LinearLayout.LayoutParams(
                    ViewGroup.LayoutParams.WRAP_CONTENT,
                    ViewGroup.LayoutParams.WRAP_CONTENT
            );
            buttonParams.setMargins(16, 0, 16, 16); // Add margin for spacing
            downloadButton.setLayoutParams(buttonParams);
            downloadButton.setText("Download");
            downloadButton.setTextColor(getResources().getColor(android.R.color.white));
            downloadButton.setBackgroundResource(R.drawable.button_background);
            downloadButton.setVisibility(View.GONE); // Initially hidden
            container.addView(downloadButton);

            // Set click listener on expand/collapse icon to toggle answer visibility and icon
            expandCollapseIcon.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    if (answerTextView.getVisibility() == View.VISIBLE) {
                        answerTextView.setVisibility(View.GONE);
                        downloadButton.setVisibility(View.GONE); // Hide download button
                        expandCollapseIcon.setImageResource(R.drawable.ic_expand_more); // Change to expand icon
                    } else {
                        answerTextView.setVisibility(View.VISIBLE);
                        downloadButton.setVisibility(View.VISIBLE); // Show download button
                        expandCollapseIcon.setImageResource(R.drawable.ic_expand_less); // Change to collapse icon
                    }
                }
            });

            // Set click listener on download Button to initiate download process
            downloadButton.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    // Implement download logic
                    downloadDocument(documentName);
                }
            });
        } else {
            // Set click listener on expand/collapse icon to toggle answer visibility and icon
            expandCollapseIcon.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    if (answerTextView.getVisibility() == View.VISIBLE) {
                        answerTextView.setVisibility(View.GONE);
                        expandCollapseIcon.setImageResource(R.drawable.ic_expand_more); // Change to expand icon
                    } else {
                        answerTextView.setVisibility(View.VISIBLE);
                        expandCollapseIcon.setImageResource(R.drawable.ic_expand_less); // Change to collapse icon
                    }
                }
            });

            // Set click listener on answer TextView to open URL if it contains a web address
            answerTextView.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    String text = answerTextView.getText().toString();
                    if (text.contains("www.food.wb.gov.in")) {
                        // Open URL in a web browser
                        Intent intent = new Intent(Intent.ACTION_VIEW, Uri.parse("http://" + text));
                        startActivity(intent);
                    }
                }
            });
        }
    }

    private void downloadDocument(String documentName) {
        DownloadManager downloadManager = (DownloadManager) getSystemService(DOWNLOAD_SERVICE);
        Uri uri = Uri.parse("https://docs.google.com/spreadsheets/d/1dVQsDNstekdA6HBb0IRaAFtftGlaJStr/edit?usp=drive_link&ouid=112900821562061951842&rtpof=true&sd=true " + documentName);
        DownloadManager.Request request = new DownloadManager.Request(uri);
        request.setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED);
        downloadManager.enqueue(request);
    }
}
