package com.example.pds_public;

public class ShopInfo{

    private String district;
    private String taluk;
    private String shopNumber;
    private String shopName;
    private int totalFamilyPresent;
    private String status;
    private String ratioDetails;

    // Default constructor required for Firebase
    public ShopInfo() {
    }

    public ShopInfo(String district, String taluk, String shopNumber, String shopName,
                       int totalFamilyPresent, String status, String ratioDetails) {
        this.district = district;
        this.taluk = taluk;
        this.shopNumber = shopNumber;
        this.shopName = shopName;
        this.totalFamilyPresent = totalFamilyPresent;
        this.status = status;
        this.ratioDetails = ratioDetails;
    }

    public String getDistrict() {
        return district;
    }

    public String getTaluk() {
        return taluk;
    }

    public String getShopNumber() {
        return shopNumber;
    }

    public String getShopName() {
        return shopName;
    }

    public int getTotalFamilyPresent() {
        return totalFamilyPresent;
    }

    public String getStatus() {
        return status;
    }

    public String getRatioDetails() {
        return ratioDetails;
    }
}