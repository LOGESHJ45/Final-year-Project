package com.example.pds_public;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageButton;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

public class OfficerHomePage extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_officer_home_page);

        ImageButton imageButton1 = findViewById(R.id.imageButton1);
        ImageButton imageButton2 = findViewById(R.id.imageButton2);
        ImageButton imageButton3 = findViewById(R.id.imageButton3);
        ImageButton imageButton4 = findViewById(R.id.imageButton4);
        ImageButton imageButton5 = findViewById(R.id.imageButton5);
        ImageButton imageButton6 = findViewById(R.id.imageButton6);

        imageButton4.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                showChooseActivityDialog();
            }
        });

        // Set OnClickListener for each ImageButton
        imageButton1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Handle ImageButton 1 click
                startActivity(new Intent(OfficerHomePage.this, AddUser.class));
            }
        });

        imageButton2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Handle ImageButton 2 click
                startActivity(new Intent(OfficerHomePage.this, RemoveUser.class));
            }
        });

        imageButton3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Handle ImageButton 3 click
                startActivity(new Intent(OfficerHomePage.this, NotifyUser.class));
            }
        });

        imageButton5.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Handle ImageButton 5 click
                startActivity(new Intent(OfficerHomePage.this, OfficerData.class));
            }
        });

        imageButton6.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Handle ImageButton 6 click

                    // Clear the saved email from SharedPreferences
                    clearUserPreferences();

                    // Optionally, you can redirect the user to the login screen
                    Intent intent = new Intent(OfficerHomePage.this,OfficerLogin.class);
                    startActivity(intent);
                    finish();
                }

                public void clearUserPreferences(){
                    SharedPreferences preferences = getSharedPreferences("User", MODE_PRIVATE);
                    SharedPreferences.Editor editor = preferences.edit();
                    editor.remove("userEmail");
                    editor.apply();
                }

        });
    }

    private void showChooseActivityDialog() {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        View dialogView = getLayoutInflater().inflate(R.layout.dialog_choose_activity, null);
        builder.setView(dialogView);

        AlertDialog dialog = builder.create();
        dialog.show();

        Button btnActivity1 = dialogView.findViewById(R.id.btnActivity1);
        Button btnActivity2 = dialogView.findViewById(R.id.btnActivity2);

        btnActivity1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                startActivity(new Intent(OfficerHomePage.this, ShopDetails.class));
                dialog.dismiss();
            }


        });


        btnActivity2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(OfficerHomePage.this, ShopDetailsSecondPage.class));
                dialog.dismiss();
            }
        });
    }
}

