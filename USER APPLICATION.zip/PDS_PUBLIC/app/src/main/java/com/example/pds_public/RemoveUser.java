package com.example.pds_public;
// DeleteUserActivity.java


import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

public class RemoveUser extends AppCompatActivity {

    private EditText editTextPhoneNumberToDelete, editTextSmartCardNumberToDelete;
    private Button buttonDeleteUser;

    private DatabaseReference mDatabase;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_remove_user);

        mDatabase = FirebaseDatabase.getInstance().getReference();

        editTextPhoneNumberToDelete = findViewById(R.id.editTextPhoneNumberToDelete);
        editTextSmartCardNumberToDelete = findViewById(R.id.editTextSmartCardNumberToDelete);
        buttonDeleteUser = findViewById(R.id.buttonDeleteUser);

        buttonDeleteUser.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                deleteUser();
            }
        });
    }

    private void deleteUser() {
        final String phoneNumberToDelete = editTextPhoneNumberToDelete.getText().toString().trim();
        final String smartCardNumberToDelete = editTextSmartCardNumberToDelete.getText().toString().trim();

        // Check if the user exists in any shop node
        mDatabase.addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                boolean userExists = false;

                for (DataSnapshot shopSnapshot : dataSnapshot.getChildren()) {
                    if (shopSnapshot.child(phoneNumberToDelete).exists()
                            && shopSnapshot.child(phoneNumberToDelete).child("smartCardNumber").getValue(String.class).equals(smartCardNumberToDelete)) {
                        // User found, delete the user data
                        userExists = true;
                        deleteUserData(phoneNumberToDelete, shopSnapshot.getKey());
                        break;
                    }
                }

                if (!userExists) {
                    // User not found, display an error toast
                    Toast.makeText(RemoveUser.this, "User not found. Please check the provided details.", Toast.LENGTH_SHORT).show();
                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {
                // Handle the error, if needed
                Toast.makeText(RemoveUser.this, "Error checking user: " + databaseError.getMessage(), Toast.LENGTH_SHORT).show();
            }
        });
    }

    private void deleteUserData(String phoneNumber, String shopName) {
        // Delete the user data from the specified shop node
        mDatabase.child(shopName).child(phoneNumber).removeValue();
        Toast.makeText(RemoveUser.this, "User data deleted successfully.", Toast.LENGTH_SHORT).show();
    }
}
