package com.example.pds_public;

import android.content.SharedPreferences;
import android.os.AsyncTask;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.telesign.MessagingClient;
import com.telesign.RestClient;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;

public class NotifyUser extends AppCompatActivity {

    private EditText editTextMessage;
    private Spinner spinnerShop;
    private Spinner spinnerStreet;
    private Button buttonSubmit;

    private DatabaseReference shopDetailsReference;
    private SharedPreferences preferences;
    private boolean isMessageSaved = false;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_notify_user);

        editTextMessage = findViewById(R.id.editTextMessage);
        spinnerShop = findViewById(R.id.spinnerShop);
        spinnerStreet = findViewById(R.id.spinnerStreet);
        buttonSubmit = findViewById(R.id.buttonSubmit);

        shopDetailsReference = FirebaseDatabase.getInstance().getReference("ShopDetails");

        // Retrieve user's email from SharedPreferences
        preferences = getSharedPreferences("User", MODE_PRIVATE);
        String userEmail = preferences.getString("userEmail", "");

        // Populate shop spinner based on user's email
        populateShopSpinner(userEmail);

        // Set listener for shop selection
        spinnerShop.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parentView, View selectedItemView, int position, long id) {
                // Populate streets for the selected shop
                populateStreetSpinner(spinnerShop.getSelectedItem().toString());
            }

            @Override
            public void onNothingSelected(AdapterView<?> parentView) {
                // Do nothing here
            }
        });

        buttonSubmit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String selectedShop = spinnerShop.getSelectedItem().toString();
                String selectedStreet = spinnerStreet.getSelectedItem().toString();
                String message = editTextMessage.getText().toString().trim();

                // Get the selected checklist items
                String selectedChecklists = getSelectedChecklists();

                // Append selected checklist items to the message
                if (!selectedChecklists.isEmpty()&&message.isEmpty()) {

                    message += "\n\nDear PDS users of " + selectedStreet + " in " + selectedShop + ", We are distributing the following items: " + selectedChecklists + " to our street!";
                }

                if (!message.isEmpty()) {
                    if (!isMessageSaved) {

                        saveMessage(selectedShop, selectedStreet, message);
                        isMessageSaved = true;
                        buttonSubmit.setText("Send SMS");
                    } else {
                        // Fetch phone numbers and execute the Telesign SMS sending task
                        getPhoneNumbersForStreet(selectedShop, selectedStreet, message);
                    }
                } else {
                    Toast.makeText(NotifyUser.this, "Please enter a message", Toast.LENGTH_SHORT).show();
                }
            }
        });
    }

    private String getSelectedChecklists() {
        // List to store selected checklist items
        List<String> selectedItems = new ArrayList<>();

        // Retrieve selected checklist items from the checkboxes
        CheckBox checkBoxRice = findViewById(R.id.checkBoxRice);
        CheckBox checkBoxSugar = findViewById(R.id.checkBoxSugar);
        CheckBox checkBoxWheat = findViewById(R.id.checkBoxWheat);
        CheckBox checkBoxPulse = findViewById(R.id.checkBoxPulse);
        CheckBox checkBoxKerosene = findViewById(R.id.checkBoxKerosene);
        CheckBox checkBoxPalmOil = findViewById(R.id.checkBoxPalmOil);

        // Check if each checkbox is checked, and add the corresponding item to the list
        if (checkBoxRice.isChecked()) {
            selectedItems.add("RICE");
        }
        if (checkBoxSugar.isChecked()) {
            selectedItems.add("SUGAR");
        }
        if (checkBoxWheat.isChecked()) {
            selectedItems.add("WHEAT");
        }
        if (checkBoxPulse.isChecked()) {
            selectedItems.add("PULSE");
        }
        if (checkBoxKerosene.isChecked()) {
            selectedItems.add("KEROSENE");
        }
        if (checkBoxPalmOil.isChecked()) {
            selectedItems.add("PALMOIL");
        }

        // Concatenate selected checklist items into a single string
        String selectedChecklists = TextUtils.join(", ", selectedItems);

        // Get the current date and time
        SimpleDateFormat sdf = new SimpleDateFormat("hh:mm a, dd-MM-yyyy", Locale.getDefault());
        String currentDateAndTime = sdf.format(new Date());

        // Append the current date and time to the selected checklist items
        return selectedChecklists + " [" + currentDateAndTime + "]";
    }

    private void populateShopSpinner(String userEmail) {
        DatabaseReference usersReference = FirebaseDatabase.getInstance().getReference("users");
        usersReference.orderByChild("email").equalTo(userEmail).addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                if (dataSnapshot.exists()) {
                    for (DataSnapshot snapshot : dataSnapshot.getChildren()) {
                        String shopName = snapshot.child("name").getValue(String.class);
                        if (shopName != null && !shopName.isEmpty()) {
                            List<String> shopList = new ArrayList<>();
                            shopList.add(shopName);
                            ArrayAdapter<String> shopAdapter = new ArrayAdapter<>(NotifyUser.this, android.R.layout.simple_spinner_item, shopList);
                            shopAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
                            spinnerShop.setAdapter(shopAdapter);
                        } else {
                            Toast.makeText(NotifyUser.this, "Shop name not found for user", Toast.LENGTH_SHORT).show();
                        }
                    }
                } else {
                    Toast.makeText(NotifyUser.this, "User not found in the database", Toast.LENGTH_SHORT).show();
                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {
                Toast.makeText(NotifyUser.this, "Error: " + databaseError.getMessage(), Toast.LENGTH_SHORT).show();
            }
        });
    }

    private void populateStreetSpinner(String selectedShop) {
        shopDetailsReference.child(selectedShop).child("streetdetails").addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                if (dataSnapshot.exists()) {
                    List<String> streetNames = new ArrayList<>();
                    for (DataSnapshot snapshot : dataSnapshot.getChildren()) {
                        streetNames.add(snapshot.getKey());
                    }

                    ArrayAdapter<String> streetAdapter = new ArrayAdapter<>(NotifyUser.this, android.R.layout.simple_spinner_item, streetNames);
                    streetAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
                    spinnerStreet.setAdapter(streetAdapter);
                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {
                Toast.makeText(NotifyUser.this, "Error: " + databaseError.getMessage(), Toast.LENGTH_SHORT).show();
            }
        });
    }

    private void saveMessage(String selectedShop, String selectedStreet, String message) {
        // First, set the message for the selected street
        shopDetailsReference.child(selectedShop).child("streetdetails").child(selectedStreet).child("message").setValue(message)
                .addOnCompleteListener(task -> {
                    if (task.isSuccessful()) {
                        Toast.makeText(NotifyUser.this, "Message saved successfully", Toast.LENGTH_SHORT).show();
                        // Now, iterate through each child node of the street and set the message label
                        shopDetailsReference.child(selectedShop).child("streetdetails").child(selectedStreet)
                                .addListenerForSingleValueEvent(new ValueEventListener() {
                                    @Override
                                    public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                                        if (dataSnapshot.exists()) {
                                            for (DataSnapshot childSnapshot : dataSnapshot.getChildren()) {
                                                childSnapshot.getRef().child("message").setValue(message);
                                            }
                                        }
                                    }

                                    @Override
                                    public void onCancelled(@NonNull DatabaseError databaseError) {
                                        Toast.makeText(NotifyUser.this, "Error: " + databaseError.getMessage(), Toast.LENGTH_SHORT).show();
                                    }
                                });
                    } else {
                        Toast.makeText(NotifyUser.this, "Failed to save message", Toast.LENGTH_SHORT).show();
                    }
                });
    }


    private void getPhoneNumbersForStreet(String selectedShop, String selectedStreet, String message) {
        shopDetailsReference.child(selectedShop).child("streetdetails").child(selectedStreet).addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                if (dataSnapshot.exists()) {
                    Map<String, String> phoneNumbers = new HashMap<>();
                    for (DataSnapshot userSnapshot : dataSnapshot.getChildren()) {
                        String phoneNumber = userSnapshot.child("phoneNumber").getValue(String.class);
                        phoneNumbers.put(userSnapshot.getKey(), phoneNumber);
                    }

                    if (!phoneNumbers.isEmpty()) {
                        // Execute the Telesign SMS sending task
                        new SendSMSTask("FE3F0015-9EC3-4C6B-9F87-D158FEB9F2B1", "z9NJ1vE5nqLJEu8WpaK2s8jeb9eEPfa8doIMHappClXYyElQydJlrE+LNNpw8sXwoyYcu4oS3ZrIVtkL5S8Y6A==", selectedShop, selectedStreet, message, "ARN", phoneNumbers).execute();
                    } else {
                        Toast.makeText(NotifyUser.this, "No phone numbers found for " + selectedStreet, Toast.LENGTH_SHORT).show();
                    }
                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {
                Toast.makeText(NotifyUser.this, "Error: " + databaseError.getMessage(), Toast.LENGTH_SHORT).show();
            }
        });
    }

    private class SendSMSTask extends AsyncTask<Void, Void, String> {
        private final String customerId;
        private final String apiKey;
        private final String selectedShop;
        private final String selectedStreet;
        private final String message;
        private final String messageType;
        private final Map<String, String> phoneNumbers;

        public SendSMSTask(String customerId, String apiKey, String selectedShop, String selectedStreet, String message, String messageType, Map<String, String> phoneNumbers) {
            this.customerId = customerId;
            this.apiKey = apiKey;
            this.selectedShop = selectedShop;
            this.selectedStreet = selectedStreet;
            this.message = message;
            this.messageType = messageType;
            this.phoneNumbers = phoneNumbers;
        }

        @Override
        protected String doInBackground(Void... voids) {
            try {
                // Instantiate a messaging client object.
                MessagingClient messagingClient = new MessagingClient(customerId, apiKey);

                // Send messages to all phone numbers in the street
                for (Map.Entry<String, String> entry : phoneNumbers.entrySet()) {
                    String phoneNumber = entry.getValue();
                    // Make the request and capture the response.
                    RestClient.TelesignResponse telesignResponse = messagingClient.message(phoneNumber, message, messageType, null);
                    // Check if the SMS was sent successfully
                    if (telesignResponse.statusCode != 200) {
                        return "Failed to send SMS to " + phoneNumber + ". Status code: " + telesignResponse.statusCode +
                                ", Response: " + telesignResponse.body;
                    }
                }
                return "SMS sent successfully to all numbers in " + selectedStreet;
            } catch (Exception e) {
                e.printStackTrace();
                return "Exception occurred: " + e.getMessage();
            }
        }

        @Override
        protected void onPostExecute(String result) {
            Toast.makeText(NotifyUser.this, result, Toast.LENGTH_SHORT).show();
        }
    }
}