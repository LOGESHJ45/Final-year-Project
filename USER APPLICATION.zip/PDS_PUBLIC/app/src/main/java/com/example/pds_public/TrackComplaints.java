package com.example.pds_public;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

public class TrackComplaints extends AppCompatActivity {

    EditText tokenEditText;
    Button showDetailsButton;
    TextView complaintDetailsTextView;

    DatabaseReference databaseReference;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_track_complaints);

        tokenEditText = findViewById(R.id.tokenEditText);
        showDetailsButton = findViewById(R.id.showDetailsButton);
        complaintDetailsTextView = findViewById(R.id.complaintDetailsTextView);

        // Initialize the database reference
        databaseReference = FirebaseDatabase.getInstance().getReference().child("complaints");

        showDetailsButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String token = tokenEditText.getText().toString().trim();
                if (!TextUtils.isEmpty(token)) {
                    // Call a method to retrieve complaint details based on the token
                    displayComplaintDetails(token);
                } else {
                    Toast.makeText(TrackComplaints.this, "Please enter a token number", Toast.LENGTH_SHORT).show();
                }
            }
        });
    }

    private void displayComplaintDetails(String token) {
        databaseReference.child(token).addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                if (dataSnapshot.exists()) {
                    // Data found for the given token
                    Complaint complaint = dataSnapshot.getValue(Complaint.class);
                    if (complaint != null) {
                        // Build the string to display
                        String details = "Body: " + complaint.getBody() + "\n" +
                                "Recipient Email: " + complaint.getRecipientEmail() + "\n" +
                                "Recipient Type: " + complaint.getRecipientType() + "\n" +
                                "Status: " + complaint.getStatus() + "\n" +
                                "Subject: " + complaint.getSubject() + "\n" +
                                "Additional Info: " + complaint.getAdditionalInfo() + "\n" +
                                "Phone Number: " + complaint.getPhoneNumber() + "\n" +
                                "Sender Email: " + complaint.getSenderEmail() + "\n" +
                                "Time: " + complaint.getTime();

                        // Set the details to TextView
                        complaintDetailsTextView.setText(details);
                        complaintDetailsTextView.setVisibility(View.VISIBLE); // Make the TextView visible
                    }
                } else {
                    // Data not found for the given token
                    Toast.makeText(TrackComplaints.this, "No data found for token: " + token, Toast.LENGTH_SHORT).show();
                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {
                Toast.makeText(TrackComplaints.this, "Failed to retrieve data: " + databaseError.getMessage(), Toast.LENGTH_SHORT).show();
            }
        });
    }

}
