package com.example.pds_public;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

public class OfficerData extends AppCompatActivity {

    private DatabaseReference mDatabase;
    private TextView textViewShopName;
    private EditText editTextStreet;
    private Button btnSubmitStreet;
    private String officerName;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_officer_data);

        mDatabase = FirebaseDatabase.getInstance().getReference();

        textViewShopName = findViewById(R.id.textViewGreeting);
        editTextStreet = findViewById(R.id.editTextStreet);
        btnSubmitStreet = findViewById(R.id.btnSubmit);

        // Retrieve officer's email from SharedPreferences
        String userEmail = getUserEmailFromPreferences();

        // Retrieve officer's name from Firebase based on the email
        getOfficerName(userEmail);

        btnSubmitStreet.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (officerName != null && !officerName.isEmpty()) {
                    submitStreet(officerName);
                } else {
                    Toast.makeText(OfficerData.this, "Officer's name not found", Toast.LENGTH_SHORT).show();
                }
            }
        });
    }

    private String getUserEmailFromPreferences() {
        SharedPreferences preferences = getSharedPreferences("User", MODE_PRIVATE);
        return preferences.getString("userEmail", "");
    }

    private void getOfficerName(String email) {
        mDatabase.child("users").addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                for (DataSnapshot userSnapshot : dataSnapshot.getChildren()) {
                    UserData userData = userSnapshot.getValue(UserData.class);

                    if (userData != null && userData.getEmail().equals(email)) {
                        officerName = userData.getName();
                        updateGreeting(officerName);
                        return;
                    }
                }

                // Handle the case where the officer's name is not found
                Toast.makeText(OfficerData.this, "Officer's name not found", Toast.LENGTH_SHORT).show();
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {
                // Handle the error, if needed
                Toast.makeText(OfficerData.this, "Error retrieving officer's name: " + databaseError.getMessage(), Toast.LENGTH_SHORT).show();
            }
        });
    }

    private void updateGreeting(String officerName) {
        // Update the greeting TextView with the officer's name
        textViewShopName.setText("Hi " + officerName);
    }

    private void submitStreet(String officerName) {
        final String streetName = editTextStreet.getText().toString().trim();

        if (streetName.isEmpty()) {
            Toast.makeText(this, "Please enter the street name", Toast.LENGTH_SHORT).show();
            return;
        }

        // Path to the street details node for the specific shop
        final String shopDetailsPath = "ShopDetails/" + officerName.toLowerCase() + "/streetdetails";

        // Create a new node under 'streetdetails' for the street information
        String streetNodePath = shopDetailsPath + "/" + streetName;

        // Check if the street name already exists in the respective shop's 'streetdetails'
        mDatabase.child(streetNodePath).addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                if (dataSnapshot.exists()) {
                    // Street name already exists in the shop's 'streetdetails'
                    Toast.makeText(OfficerData.this, "Street already exists for this shop", Toast.LENGTH_SHORT).show();
                } else {
                    // Street name doesn't exist, add it as a new node
                    mDatabase.child(streetNodePath).setValue(true, new DatabaseReference.CompletionListener() {
                        @Override
                        public void onComplete(@NonNull DatabaseError databaseError, @NonNull DatabaseReference databaseReference) {
                            if (databaseError == null) {
                                Toast.makeText(OfficerData.this, "Street details added successfully", Toast.LENGTH_SHORT).show();
                            } else {
                                Toast.makeText(OfficerData.this, "Error adding street details: " + databaseError.getMessage(), Toast.LENGTH_SHORT).show();
                            }
                        }
                    });
                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {
                Toast.makeText(OfficerData.this, "Database error: " + databaseError.getMessage(), Toast.LENGTH_SHORT).show();
            }
        });
    }
}
