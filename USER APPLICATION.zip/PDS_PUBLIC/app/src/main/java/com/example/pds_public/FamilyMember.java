package com.example.pds_public;

public class FamilyMember {
    private String name;
    private String aadharNumber;
    private String age;

    public FamilyMember() {
        // Default constructor required for Firebase
    }

    public FamilyMember(String name, String aadharNumber, String age) {
        this.name = name;
        this.aadharNumber = aadharNumber;
        this.age = age;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getAadharNumber() {
        return aadharNumber;
    }

    public void setAadharNumber(String aadharNumber) {
        this.aadharNumber = aadharNumber;
    }

    public String getAge() {
        return age;
    }

    public void setAge(String age) {
        this.age = age;
    }
}