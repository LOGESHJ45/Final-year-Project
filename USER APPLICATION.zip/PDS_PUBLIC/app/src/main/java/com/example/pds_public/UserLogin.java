package com.example.pds_public;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import com.google.firebase.FirebaseException;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.PhoneAuthCredential;
import com.google.firebase.auth.PhoneAuthProvider;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.concurrent.TimeUnit;

public class UserLogin extends AppCompatActivity {

    private EditText editTextPhoneNumber;
    private EditText editTextOTP;
    private Button buttonGenerateOTP;
    private Button buttonLogin;
    private Button buttonRegister;

    private FirebaseAuth mAuth;
    private String verificationId;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_user_login);

        mAuth = FirebaseAuth.getInstance();

        editTextPhoneNumber = findViewById(R.id.editTextEmail);
        editTextOTP = findViewById(R.id.editTextPassword);
        buttonGenerateOTP = findViewById(R.id.button);
        buttonLogin = findViewById(R.id.buttonLogin);
        buttonRegister = findViewById(R.id.buttonRegister);


        buttonGenerateOTP.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String phoneNumber = editTextPhoneNumber.getText().toString().trim();
                if (!phoneNumber.isEmpty()) {
                    // Save phone number to SharedPreferences
                    savePhoneNumber(phoneNumber);

                } else {
                    Toast.makeText(UserLogin.this, "Please enter a phone number", Toast.LENGTH_SHORT).show();
                }
                generateOTP();
            }
        });

        buttonLogin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String otp = editTextOTP.getText().toString().trim();
                if (!otp.isEmpty()) {
                    // Verify OTP and proceed to homepage if verified

                    signInWithPhoneNumber(otp);
                } else {
                    // Empty OTP
                    Toast.makeText(UserLogin.this, "Please enter OTP", Toast.LENGTH_SHORT).show();
                }
            }
        });

        buttonRegister.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                // Navigate to registration page
                Intent intent = new Intent(UserLogin.this, RegisterUser.class);
                startActivity(intent);
            }
        });
    }
    private void savePhoneNumber(String phoneNumber) {
        SharedPreferences.Editor editor = getSharedPreferences("MyPrefs", MODE_PRIVATE).edit();
        editor.putString("phoneNumber", phoneNumber);
        editor.apply();
    }

    private void generateOTP() {
        String phoneNumber = editTextPhoneNumber.getText().toString().trim();
        if (!phoneNumber.isEmpty()) {
            // Verify phone number in the database
            verifyPhoneNumberInDatabase(phoneNumber);
        } else {
            // Empty phone number
            Toast.makeText(UserLogin.this, "Please enter a phone number", Toast.LENGTH_SHORT).show();
        }
    }

    private void verifyPhoneNumberInDatabase(String phoneNumber) {
        DatabaseReference shopDetailsRef = FirebaseDatabase.getInstance().getReference().child("ShopDetails");
        shopDetailsRef.addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                boolean phoneNumberFound = false;
                for (DataSnapshot shopSnapshot : dataSnapshot.getChildren()) {
                    for (DataSnapshot streetSnapshot : shopSnapshot.child("streetdetails").getChildren()) {
                        for (DataSnapshot phoneNumberSnapshot : streetSnapshot.getChildren()) {
                            String number = phoneNumberSnapshot.getKey();
                            if (number != null && number.equals(phoneNumber)) {
                                // Phone number found in the database
                                phoneNumberFound = true;
                                // Proceed with phone authentication
                                sendOTP("+"+phoneNumber);
                                break;
                            }
                        }
                    }
                    if (phoneNumberFound) {
                        break;
                    }
                }

                if (!phoneNumberFound) {
                    // Phone number not found in the database
                    Toast.makeText(UserLogin.this, "Phone number not found in the database. Please register to continue.", Toast.LENGTH_SHORT).show();
                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {
                // Handle errors
                Toast.makeText(UserLogin.this, "Failed to read database: " + databaseError.getMessage(), Toast.LENGTH_SHORT).show();
            }
        });
    }

    private void sendOTP(String phoneNumber) {
        PhoneAuthProvider.getInstance().verifyPhoneNumber(
                phoneNumber,
                60,
                TimeUnit.SECONDS,
                this,
                new PhoneAuthProvider.OnVerificationStateChangedCallbacks() {
                    @Override
                    public void onVerificationCompleted(@NonNull PhoneAuthCredential phoneAuthCredential) {
                        // Auto-retrieval or instant verification of OTP
                        signInWithPhoneAuthCredential(phoneAuthCredential);
                    }

                    @Override
                    public void onVerificationFailed(@NonNull FirebaseException e) {
                        // Failed to send OTP
                        Toast.makeText(UserLogin.this, "Failed to send OTP: " + e.getMessage(), Toast.LENGTH_SHORT).show();
                    }

                    @Override
                    public void onCodeSent(@NonNull String s, @NonNull PhoneAuthProvider.ForceResendingToken forceResendingToken) {
                        // OTP sent successfully
                        verificationId = s;
                        Toast.makeText(UserLogin.this, "OTP sent successfully", Toast.LENGTH_SHORT).show();
                    }
                });
    }

    private void signInWithPhoneNumber(String otp) {
        PhoneAuthCredential credential = PhoneAuthProvider.getCredential(verificationId, otp);
        signInWithPhoneAuthCredential(credential);
    }

    private void signInWithPhoneAuthCredential(PhoneAuthCredential credential) {
        mAuth.signInWithCredential(credential)
                .addOnCompleteListener(this, task -> {
                    if (task.isSuccessful()) {
                        // Authentication successful, navigate to homepage
                        Toast.makeText(UserLogin.this, "Authentication successful", Toast.LENGTH_SHORT).show();
                        Intent intent = new Intent(UserLogin.this, UserHomePage.class);
                        // Pass phone number to UserHomePage
                        intent.putExtra("phoneNumber", editTextPhoneNumber.getText().toString().trim());
                        startActivity(intent);
                        finish();
                    }
                    else {
                        // Authentication failed
                        Toast.makeText(UserLogin.this, "Authentication failed", Toast.LENGTH_SHORT).show();
                    }
                });
    }
}