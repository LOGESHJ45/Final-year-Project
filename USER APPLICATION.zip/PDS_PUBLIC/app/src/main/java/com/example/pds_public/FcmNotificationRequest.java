package com.example.pds_public;

import com.google.gson.annotations.SerializedName;

public class FcmNotificationRequest {

    @SerializedName("registration_ids")
    private String[] registrationIds;

    @SerializedName("data")
    private FcmNotificationData data;

    public FcmNotificationRequest(String[] registrationIds, FcmNotificationData data) {
        this.registrationIds = registrationIds;
        this.data = data;
    }
}
