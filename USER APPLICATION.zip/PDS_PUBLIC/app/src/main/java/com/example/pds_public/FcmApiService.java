package com.example.pds_public;
import okhttp3.ResponseBody;
import retrofit2.Call;
import retrofit2.http.Body;
import retrofit2.http.Headers;
import retrofit2.http.POST;

public interface FcmApiService {

    @Headers({
            "Authorization: key=AAAAkZPz_xY:APA91bHddlbWXg8sFYZkiVL_Ef2_845gWb2v2MMVmJrbUYdqeVQM3OjKoHtMHJTEo54fyugVu9u1O_Dcunxpr_-p9vi6gpoT0ulWSyI-5q7M8NlBd8zNmyBS2_XuNOpXS_eqMMYG3OZH",
            "Content-Type: application/json"
    })
    @POST("fcm/send")
    Call<ResponseBody> sendNotification(@Body FcmNotificationRequest notificationRequest);
}
