package com.example.pds_public;

public class UserData {
    private String email;
    private String password;
    String name;

    // Required default constructor for Firebase
    public UserData() {
    }

    public UserData(String email, String password) {
        this.email = email;
        this.password = password;
    }

    public String getEmail() {
        return email;
    }

    public String getPassword() {
        return password;
    }

    public String getName() {

        return name;
    }
}
