package com.example.pds_public;

import com.google.gson.annotations.SerializedName;

public class FcmNotificationData {

    @SerializedName("title")
    private String title;

    @SerializedName("body")
    private String body;

    public FcmNotificationData(String title, String body) {
        this.title = title;
        this.body = body;
    }
}
