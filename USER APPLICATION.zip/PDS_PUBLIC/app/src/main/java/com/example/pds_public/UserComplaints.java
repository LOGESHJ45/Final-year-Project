package com.example.pds_public;

import android.os.AsyncTask;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.*;

import androidx.appcompat.app.AppCompatActivity;

import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.telesign.MessagingClient;
import com.telesign.RestClient;

import okhttp3.*;

import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Random;

public class UserComplaints extends AppCompatActivity {

    private static final String TAG = UserComplaints.class.getSimpleName();
    private DatabaseReference mDatabase;
    private boolean isFirstClick = true;
    private TextView tokenTextView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_user_complaints);

        // Initialize Firebase Database
        mDatabase = FirebaseDatabase.getInstance().getReference();

        // Initialize Spinner, EditText, and Button views
        Spinner spinnerRecipientType = findViewById(R.id.spinnerRecipientType);
        EditText editTextSubject = findViewById(R.id.editTextSubject);
        EditText editTextBody = findViewById(R.id.editTextBody);
        EditText editTextSenderEmail = findViewById(R.id.editTextSenderEmail);
        EditText editTextPhoneNumber = findViewById(R.id.editTextPhoneNumber);
        Button buttonSend = findViewById(R.id.buttonSend);
        tokenTextView = findViewById(R.id.tokenTextView);

        // Populate the spinner with items from the string array
        ArrayAdapter<CharSequence> adapter = ArrayAdapter.createFromResource(this,
                R.array.recipient_types, android.R.layout.simple_spinner_item);
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinnerRecipientType.setAdapter(adapter);

        // Set onClickListener for the send button
        buttonSend.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (isFirstClick) {
                    saveComplaintToDatabase();
                    isFirstClick = false;
                } else {
                    sendEmailAndSMS();
                }
            }
        });
    }

    private void saveComplaintToDatabase() {
        // Generate a random token for the complaint
        String token = generateRandomToken();

        // Set the generated token to the TextView
        tokenTextView.setText("Token: " + token);
        tokenTextView.setVisibility(View.VISIBLE); // Make the token visible

        // Get user input from EditText fields
        Spinner spinnerRecipientType = findViewById(R.id.spinnerRecipientType);
        String recipientType = spinnerRecipientType.getSelectedItem().toString();

        EditText editTextSubject = findViewById(R.id.editTextSubject);
        EditText editTextBody = findViewById(R.id.editTextBody);
        EditText editTextSenderEmail = findViewById(R.id.editTextSenderEmail);
        EditText editTextPhoneNumber = findViewById(R.id.editTextPhoneNumber);

        String subject = editTextSubject.getText().toString().trim();
        String body = editTextBody.getText().toString().trim();
        String senderEmail = editTextSenderEmail.getText().toString().trim();
        String phoneNumber = editTextPhoneNumber.getText().toString().trim();

        // Get current time in hours and minutes format
        String time = getCurrentTime();

        // Store the complaint in Firebase Realtime Database under "complaints" node
        Complaint complaint = new Complaint(recipientType, getRecipientEmail(recipientType), subject, body, token, "Sent", senderEmail, phoneNumber, time);

        mDatabase.child("complaints").child(token).setValue(complaint);
    }

    private void sendEmailAndSMS() {
        // Get user input from EditText fields
        String recipientEmail = getRecipientEmail(((Spinner) findViewById(R.id.spinnerRecipientType)).getSelectedItem().toString());
        String subject = ((EditText) findViewById(R.id.editTextSubject)).getText().toString().trim();
        String body = ((EditText) findViewById(R.id.editTextBody)).getText().toString().trim();
        String authorizationToken = getAuthorizationToken(((Spinner) findViewById(R.id.spinnerRecipientType)).getSelectedItem().toString());
        String phoneNumber = ((EditText) findViewById(R.id.editTextPhoneNumber)).getText().toString().trim(); // Get phone number directly from EditText

        // Check if any field is empty
        if (recipientEmail.isEmpty() || subject.isEmpty() || body.isEmpty() || phoneNumber.isEmpty()) {
            Toast.makeText(UserComplaints.this, "Please fill in all fields", Toast.LENGTH_SHORT).show();
            return;
        }

        // Execute AsyncTask to send email
        new EmailSender().execute(recipientEmail, subject, body, authorizationToken);

        // Send SMS using Telesign
        sendSMSToPhoneNumber(phoneNumber);
    }

    private void sendSMSToPhoneNumber(String phoneNumber) {
        String selectedRecipientType = ((Spinner) findViewById(R.id.spinnerRecipientType)).getSelectedItem().toString();
        String token = tokenTextView.getText().toString().trim().split(": ")[1]; // Extract the token from the TextView

        // Execute the Telesign SMS sending task
        getPhoneNumbersForRecipient(selectedRecipientType, phoneNumber, token);
    }

    private void getPhoneNumbersForRecipient(String recipientType, String phoneNumber, String token) {
        // Execute the Telesign SMS sending task
        new SendSMSTask("FE3F0015-9EC3-4C6B-9F87-D158FEB9F2B1", "z9NJ1vE5nqLJEu8WpaK2s8jeb9eEPfa8doIMHappClXYyElQydJlrE+LNNpw8sXwoyYcu4oS3ZrIVtkL5S8Y6A==", recipientType, token, "ARN", phoneNumber).execute();
    }

    private String generateRandomToken() {
        // Generate a random token for the complaint (for demonstration purpose)
        Random random = new Random();
        int randomInt = random.nextInt(10000); // Change the upper limit according to your requirements
        return String.valueOf(randomInt);
    }

    private String getRecipientEmail(String recipientType) {
        switch (recipientType) {
            case "Chennai":
                return "logeshjayavel45@gmail.com";
            case "District":
                return "a23859111@gmail.com";
            case "Taluk":
                return "bharath2k2@gmail.com";
            default:
                return "";
        }
    }

    private String getAuthorizationToken(String recipientType) {
        switch (recipientType) {
            case "Chennai":
                return "43387b0f4c66ddd4c593b4052067cefe";
            case "District":
                return "7ae027dc0a168c316c247939abb4e989";
            case "Taluk":
                return "49dfbbc4903051d57c646d596309e5f8";
            default:
                return "";
        }
    }

    private String getCurrentTime() {
        // Get current time in hours and minutes format
        Calendar calendar = Calendar.getInstance();
        SimpleDateFormat sdf = new SimpleDateFormat("hh:mm a"); // Format: hours:minutes AM/PM
        return sdf.format(calendar.getTime());
    }

    private class EmailSender extends AsyncTask<String, Void, String> {
        @Override
        protected String doInBackground(String... params) {
            String recipient = params[0];
            String subject = params[1];
            String body = params[2];
            String authorizationToken = params[3];

            OkHttpClient client = new OkHttpClient();

            MediaType mediaType = MediaType.parse("application/json");
            String jsonBody = "{\"from\":{\"email\":\"mailtrap@demomailtrap.com\",\"name\":\"Mailtrap Test\"},\"to\":[{\"email\":\"" + recipient + "\"}],\"subject\":\"" + subject + "\",\"text\":\"" + body + "\",\"category\":\"Integration Test\"}";
            RequestBody requestBody = RequestBody.create(mediaType, jsonBody);

            Request request = new Request.Builder()
                    .url("https://send.api.mailtrap.io/api/send")
                    .method("POST", requestBody)
                    .addHeader("Authorization", "Bearer " + authorizationToken)
                    .addHeader("Content-Type", "application/json")
                    .build();

            try {
                Response response = client.newCall(request).execute();
                if (response.isSuccessful()) {
                    return response.body().string();
                } else {
                    return "Error: " + response.code() + " - " + response.message();
                }
            } catch (IOException e) {
                Log.e(TAG, "IOException: " + e.getMessage());
                return "Error: " + e.getMessage();
            }
        }

        @Override
        protected void onPostExecute(String result) {
            super.onPostExecute(result);
            Log.d(TAG, "Email sending result: " + result);
            // Handle the result here (e.g., show a toast or update UI)
            Toast.makeText(UserComplaints.this, "Email sent successfully!", Toast.LENGTH_SHORT).show();
        }
    }

    private class SendSMSTask extends AsyncTask<Void, Void, String> {
        private final String customerId;
        private final String apiKey;
        private final String recipientType;
        private final String token;
        private final String messageType;
        private final String phoneNumber;

        public SendSMSTask(String customerId, String apiKey, String recipientType, String token, String messageType, String phoneNumber) {
            this.customerId = customerId;
            this.apiKey = apiKey;
            this.recipientType = recipientType;
            this.token = token;
            this.messageType = messageType;
            this.phoneNumber = phoneNumber;
        }

        @Override
        protected String doInBackground(Void... voids) {
            try {
                // Instantiate a messaging client object.
                MessagingClient messagingClient = new MessagingClient(customerId, apiKey);

                // Compose the message with the token
                String message = "Your complaint token for " + recipientType + " is: " + token;

                // Make the request and capture the response.
                RestClient.TelesignResponse telesignResponse = messagingClient.message(phoneNumber, message, messageType, null);

                // Check if the SMS was sent successfully
                if (telesignResponse.statusCode != 200) {
                    return "Failed to send SMS to " + phoneNumber + ". Status code: " + telesignResponse.statusCode +
                            ", Response: " + telesignResponse.body;
                }

                return "SMS sent successfully to " + phoneNumber;
            } catch (Exception e) {
                e.printStackTrace();
                return "Exception occurred: " + e.getMessage();
            }
        }

        @Override
        protected void onPostExecute(String result) {
            Toast.makeText(UserComplaints.this, result, Toast.LENGTH_SHORT).show();
        }
    }
}
