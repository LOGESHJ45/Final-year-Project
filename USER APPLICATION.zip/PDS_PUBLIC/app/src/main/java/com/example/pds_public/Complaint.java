package com.example.pds_public;

public class Complaint {
    private String recipientType;
    private String recipientEmail;
    private String subject;
    private String body;
    private String token;
    private String status;
    private String senderEmail;
    private String phoneNumber;
    private String time;
    private String additionalInfo;

    // Default constructor (required by Firebase)
    public Complaint() {
        // Default constructor required for calls to DataSnapshot.getValue(Complaint.class)
    }

    // Constructor
    // Constructor
    public Complaint(String recipientType, String recipientEmail, String subject, String body, String token, String status, String senderEmail, String phoneNumber, String time) {
        this.recipientType = recipientType;
        this.recipientEmail = recipientEmail;
        this.subject = subject;
        this.body = body;
        this.token = token;
        this.status = status;
        this.senderEmail = senderEmail;
        this.phoneNumber = phoneNumber;
        this.time = String.valueOf(time); // Set the time parameter explicitly
    }


    // Getters and setters...
    public String getRecipientType() {
        return recipientType;
    }

    public void setRecipientType(String recipientType) {
        this.recipientType = recipientType;
    }

    public String getRecipientEmail() {
        return recipientEmail;
    }

    public void setRecipientEmail(String recipientEmail) {
        this.recipientEmail = recipientEmail;
    }

    public String getSubject() {
        return subject;
    }

    public void setSubject(String subject) {
        this.subject = subject;
    }

    public String getBody() {
        return body;
    }

    public void setBody(String body) {
        this.body = body;
    }

    public String getToken() {
        return token;
    }

    public void setToken(String token) {
        this.token = token;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public String getSenderEmail() {
        return senderEmail;
    }

    public void setSenderEmail(String senderEmail) {
        this.senderEmail = senderEmail;
    }

    public String getPhoneNumber() {
        return phoneNumber;
    }

    public void setPhoneNumber(String phoneNumber) {
        this.phoneNumber = phoneNumber;
    }

    public String getTime() {
        return time;
    }

    public void setTime(String time) {
        this.time = time;
    }

    public String getAdditionalInfo() {
        return additionalInfo;
    }

    public void setAdditionalInfo(String additionalInfo) {
        this.additionalInfo = additionalInfo;
    }
}
