package com.example.pds_public;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

public class ShopDetailsSecondPage extends AppCompatActivity {

    private EditText textView2, textView4, textView6, textView8, textView10, textView12;

    // Reference to the Firebase Database
    private DatabaseReference databaseReference;
    private DatabaseReference shopDetailsReference; // Reference to the "ShopDetails" node

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_shop_details_second_page);

        // Initialize Firebase Database
        databaseReference = FirebaseDatabase.getInstance().getReference("ShopDetails");

        textView2 = findViewById(R.id.textView2);
        textView4 = findViewById(R.id.textView4);
        textView6 = findViewById(R.id.textView6);
        textView8 = findViewById(R.id.textView8);
        textView10 = findViewById(R.id.textView10);
        textView12 = findViewById(R.id.textView12);

        Button submitButton = findViewById(R.id.submitButton);
        submitButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                // Get data from EditTexts
                String data2 = textView2.getText().toString();
                String data4 = textView4.getText().toString();
                String data6 = textView6.getText().toString();
                String data8 = textView8.getText().toString();
                String data10 = textView10.getText().toString();
                String data12 = textView12.getText().toString();

                // Retrieve user email from SharedPreferences
                SharedPreferences preferences = getSharedPreferences("User", MODE_PRIVATE);
                String userEmail = preferences.getString("userEmail", "");

                // Fetch ShopNumber based on Email and upload data
                fetchShopNumberAndUploadData(userEmail, data2, data4, data6, data8, data10, data12);

                // Pass data to the next activity (if needed)
                Intent intent = new Intent(ShopDetailsSecondPage.this, NonLivy.class);
                intent.putExtra("RICE", data2);
                intent.putExtra("SUGAR", data4);
                intent.putExtra("WHEAT", data6);
                intent.putExtra("PULSE", data8);
                intent.putExtra("KEROSENE", data10);
                intent.putExtra("PALM OIL", data12);
                startActivity(intent);
            }
        });
    }

    private void fetchShopNumberAndUploadData(final String userEmail, final String data2, final String data4, final String data6, final String data8, final String data10, final String data12) {
        // Reference to the "users" node
        DatabaseReference usersReference = FirebaseDatabase.getInstance().getReference("users");

        usersReference.orderByChild("email").equalTo(userEmail).addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot dataSnapshot) {
                if (dataSnapshot.exists()) {
                    // Get the user node
                    DataSnapshot userSnapshot = dataSnapshot.getChildren().iterator().next();

                    // Get the user's name
                    String userName = userSnapshot.child("name").getValue(String.class);

                    if (userName != null && !userName.isEmpty()) {
                        // Fetch ShopNumber based on Name
                        databaseReference.orderByChild("shopNumber").equalTo(userName).addListenerForSingleValueEvent(new ValueEventListener() {
                            @Override
                            public void onDataChange(DataSnapshot dataSnapshot) {
                                if (dataSnapshot.exists()) {
                                    // Get the first matching shop
                                    DataSnapshot shopSnapshot = dataSnapshot.getChildren().iterator().next();

                                    // Get ShopNumber from the shop
                                    String shopNumber = shopSnapshot.child("shopNumber").getValue(String.class);

                                    if (shopNumber != null && !shopNumber.isEmpty()) {
                                        // Upload data to Firebase Database
                                        uploadDataToFirebase(shopNumber, data2, data4, data6, data8, data10, data12);
                                    } else {
                                        showToast("ShopNumber not found for " + userName);
                                    }
                                } else {
                                    showToast("Shop not found for " + userName);
                                }
                            }

                            @Override
                            public void onCancelled(DatabaseError databaseError) {
                                showToast("Database error: " + databaseError.getMessage());
                            }
                        });
                    } else {
                        showToast("Name not found for " + userEmail);
                    }
                } else {
                    showToast("User not found for " + userEmail);
                }
            }

            @Override
            public void onCancelled(DatabaseError databaseError) {
                showToast("Database error: " + databaseError.getMessage());
            }
        });
    }

    private void uploadDataToFirebase(String shopNumber, String data2, String data4, String data6, String data8, String data10, String data12) {
        // Upload data to the "ShopDetails" node with shopNumber as the key
        shopDetailsReference = databaseReference.child(shopNumber);

        shopDetailsReference.child("RICE").setValue(data2);
        shopDetailsReference.child("SUGAR").setValue(data4);
        shopDetailsReference.child("WHEAT").setValue(data6);
        shopDetailsReference.child("PULSE").setValue(data8);
        shopDetailsReference.child("KEROSENE").setValue(data10);
        shopDetailsReference.child("PALM OIL").setValue(data12);
    }

    private void showToast(String message) {
        // A helper method to show toast messages
        Toast.makeText(this, message, Toast.LENGTH_SHORT).show();
    }
}