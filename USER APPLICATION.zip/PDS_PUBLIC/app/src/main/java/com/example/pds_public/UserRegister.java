package com.example.pds_public;

public class UserRegister {
    public String familyHeadName;
    public String address;
    public String email;
    public String phoneNumber;
    public String smartCardNumber;
    public String aadhaarNumber;

    public UserRegister() {
        // Default constructor required for calls to DataSnapshot.getValue(UserData.class)
    }

    public UserRegister(String familyHeadName, String address, String email, String phoneNumber, String smartCardNumber ,String aadhaarNumber) {
        this.familyHeadName = familyHeadName;
        this.address = address;
        this.email = email;
        this.phoneNumber = phoneNumber;
        this.smartCardNumber = smartCardNumber;
        this.aadhaarNumber= aadhaarNumber;
    }
}
