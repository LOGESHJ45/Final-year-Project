package com.example.pds_public;

import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;
import java.util.List;

public class AddUser extends AppCompatActivity {

    private EditText editTextFamilyHeadName, editTextAddress, editTextEmail, editTextPhoneNumber, editTextSmartCardNumber, editTextAadhaarNumber;
    private Button buttonSubmit;
    private Spinner spinnerShop, spinnerStreetDetails;

    private DatabaseReference mDatabase;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register_user);

        mDatabase = FirebaseDatabase.getInstance().getReference();

        editTextFamilyHeadName = findViewById(R.id.editTextFamilyHeadName);
        editTextAddress = findViewById(R.id.editTextAddress);
        editTextEmail = findViewById(R.id.editTextEmail);
        editTextPhoneNumber = findViewById(R.id.editTextPhoneNumber);
        editTextSmartCardNumber = findViewById(R.id.editTextSmartCardNumber);
        editTextAadhaarNumber = findViewById(R.id.editTextAadhaarNumber);
        spinnerShop = findViewById(R.id.spinnerShop);
        spinnerStreetDetails = findViewById(R.id.spinnerStreetDetails);

        buttonSubmit = findViewById(R.id.buttonSubmit);
        buttonSubmit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                submitDataToFirebase();
            }
        });

        // Fetch shop names from Firebase and populate spinner
        fetchShopNames();

        // Set a listener for spinner item selection
        spinnerShop.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parentView, View selectedItemView, int position, long id) {
                // Fetch and populate street details based on the selected shop
                fetchStreetDetails(spinnerShop.getSelectedItem().toString());
            }

            @Override
            public void onNothingSelected(AdapterView<?> parentView) {
                // Do nothing here
            }
        });
    }

    private void fetchShopNames() {
        mDatabase.child("ShopDetails").addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                List<String> shopNames = new ArrayList<>();
                for (DataSnapshot shopSnapshot : dataSnapshot.getChildren()) {
                    String shopName = shopSnapshot.getKey();
                    shopNames.add(shopName);
                }

                // Populate the spinner with shop names
                ArrayAdapter<String> adapter = new ArrayAdapter<>(AddUser.this,
                        android.R.layout.simple_spinner_item, shopNames);
                adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
                spinnerShop.setAdapter(adapter);
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {
                // Handle the error, if needed
                Toast.makeText(AddUser.this, "Error fetching shop names: " + databaseError.getMessage(), Toast.LENGTH_SHORT).show();
            }
        });
    }

    private void fetchStreetDetails(String selectedShop) {
        mDatabase.child("ShopDetails").child(selectedShop).child("streetdetails").addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                List<String> streetDetailsList = new ArrayList<>();
                for (DataSnapshot streetSnapshot : dataSnapshot.getChildren()) {
                    String streetName = streetSnapshot.getKey();
                    streetDetailsList.add(streetName);
                }

                // Populate the spinner with street details
                ArrayAdapter<String> streetDetailsAdapter = new ArrayAdapter<>(AddUser.this,
                        android.R.layout.simple_spinner_item, streetDetailsList);
                streetDetailsAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
                spinnerStreetDetails.setAdapter(streetDetailsAdapter);
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {
                // Handle the error, if needed
                Toast.makeText(AddUser.this, "Error fetching street details: " + databaseError.getMessage(), Toast.LENGTH_SHORT).show();
            }
        });
    }

    private void submitDataToFirebase() {
        // Get the entered data
        final String familyHeadName = editTextFamilyHeadName.getText().toString().trim();
        final String address = editTextAddress.getText().toString().trim();
        final String email = editTextEmail.getText().toString().trim();
        final String phoneNumber = editTextPhoneNumber.getText().toString().trim();
        final String smartCardNumber = editTextSmartCardNumber.getText().toString().trim();
        final String aadhaarNumber = editTextAadhaarNumber.getText().toString().trim();
        final String selectedShop = spinnerShop.getSelectedItem().toString();
        final String selectedStreet = spinnerStreetDetails.getSelectedItem().toString();

        // Check if any field is empty
        if (familyHeadName.isEmpty() || address.isEmpty() || email.isEmpty() || phoneNumber.isEmpty() || smartCardNumber.isEmpty() || aadhaarNumber.isEmpty()) {
            // Show a toast message if any field is empty
            Toast.makeText(AddUser.this, "Please enter all fields", Toast.LENGTH_SHORT).show();
        } else {
            // Check if the phone number already exists in the database
            verifyPhoneNumberInDatabase(familyHeadName, phoneNumber, address, email, smartCardNumber, aadhaarNumber, selectedShop, selectedStreet);
        }
    }



    private void verifyPhoneNumberInDatabase(String familyHeadName, String phoneNumber, String address, String email, String smartCardNumber, String aadhaarNumber, String selectedShop, String selectedStreet) {
        DatabaseReference shopDetailsRef = FirebaseDatabase.getInstance().getReference().child("ShopDetails");
        shopDetailsRef.addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                boolean phoneNumberFound = false;
                for (DataSnapshot shopSnapshot : dataSnapshot.getChildren()) {
                    for (DataSnapshot streetSnapshot : shopSnapshot.child("streetdetails").getChildren()) {
                        for (DataSnapshot phoneNumberSnapshot : streetSnapshot.getChildren()) {
                            String number = phoneNumberSnapshot.getKey();
                            if (number != null && number.equals(phoneNumber)) {
                                // Phone number found in the database
                                phoneNumberFound = true;
                                break;
                            }
                        }
                        if (phoneNumberFound) {
                            break;
                        }
                    }
                    if (phoneNumberFound) {
                        break;
                    }
                }

                if (phoneNumberFound) {
                    // Phone number found in the database, display toast to enter a new mobile number
                    Toast.makeText(AddUser.this, "Phone number already exists in the database. Please enter a new mobile number.", Toast.LENGTH_SHORT).show();
                } else {
                    // Phone number not found in the database, proceed with uploading data
                    saveDataToFirebase(familyHeadName, address, email, phoneNumber, smartCardNumber, aadhaarNumber, selectedShop, selectedStreet);
                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {
                // Handle the error, if needed
                Toast.makeText(AddUser.this, "Error verifying phone number: " + databaseError.getMessage(), Toast.LENGTH_SHORT).show();
            }
        });
    }


    private void saveDataToFirebase(String familyHeadName, String address, String email, String phoneNumber,
                                    String smartCardNumber, String aadhaarNumber, String selectedShop, String selectedStreet) {
        // Create a data model class for better organization of data
        UserRegister userData = new UserRegister(familyHeadName, address, email, phoneNumber, smartCardNumber, aadhaarNumber);

        // Save data to a new node in Firebase Realtime Database based on the selected shop and street
        mDatabase.child("ShopDetails").child(selectedShop).child("streetdetails").child(selectedStreet).child(phoneNumber).setValue(userData);
        mDatabase.child("ShopDetails").child(selectedShop).child("streetdetails").child(selectedStreet).child(phoneNumber).child("familyHeadName").setValue(familyHeadName);
        mDatabase.child("ShopDetails").child(selectedShop).child("streetdetails").child(selectedStreet).child(phoneNumber).child("address").setValue(address);
        mDatabase.child("ShopDetails").child(selectedShop).child("streetdetails").child(selectedStreet).child(phoneNumber).child("email").setValue(email);
        mDatabase.child("ShopDetails").child(selectedShop).child("streetdetails").child(selectedStreet).child(phoneNumber).child("aadhaarNumber").setValue(aadhaarNumber);

        Toast.makeText(AddUser.this, "Data submitted successfully for " + selectedShop + ", Street: " + selectedStreet, Toast.LENGTH_SHORT).show();
    }
}
