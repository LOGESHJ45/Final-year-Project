package com.example.pds_public;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

public class UpdateFamilydetails extends AppCompatActivity {

    private EditText editTextFamilyMemberName, editTextAadharNumber, editTextAge;
    private Button buttonAddFamilyMember;
    private String phoneNumber;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_update_familydetails);

        editTextFamilyMemberName = findViewById(R.id.editTextFamilyMemberName);
        editTextAadharNumber = findViewById(R.id.editTextAadharNumber);
        editTextAge = findViewById(R.id.editTextAge);
        buttonAddFamilyMember = findViewById(R.id.buttonSave);

        // Retrieve phone number from SharedPreferences
        phoneNumber = getSharedPreferences("MyPrefs", MODE_PRIVATE)
                .getString("phoneNumber", "");

        buttonAddFamilyMember.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                addFamilyMember();
            }
        });
    }

    private void addFamilyMember() {
        String familyMemberName = editTextFamilyMemberName.getText().toString().trim();
        String aadharNumber = editTextAadharNumber.getText().toString().trim();
        String age = editTextAge.getText().toString().trim();

        if (familyMemberName.isEmpty() || aadharNumber.isEmpty() || age.isEmpty()) {
            Toast.makeText(this, "Please fill in all the fields", Toast.LENGTH_SHORT).show();
            return;
        }

        FamilyMember familyMember = new FamilyMember(familyMemberName, aadharNumber, age);

        DatabaseReference shopDetailsRef = FirebaseDatabase.getInstance().getReference()
                .child("ShopDetails");

        shopDetailsRef.addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                for (DataSnapshot shopSnapshot : dataSnapshot.getChildren()) {
                    if (shopSnapshot.child("streetdetails").exists()) {
                        for (DataSnapshot streetSnapshot : shopSnapshot.child("streetdetails").getChildren()) {
                            for (DataSnapshot phoneNumberSnapshot : streetSnapshot.getChildren()) {
                                String number = phoneNumberSnapshot.getKey();
                                if (number != null && number.equals(phoneNumber)) {
                                    DatabaseReference userRef = shopDetailsRef.child(shopSnapshot.getKey())
                                            .child("streetdetails").child(streetSnapshot.getKey()).child(number);
                                    userRef.push().setValue(familyMember)
                                            .addOnSuccessListener(aVoid -> {
                                                Toast.makeText(UpdateFamilydetails.this,
                                                        "Family member added successfully", Toast.LENGTH_SHORT).show();
                                                clearFields();
                                            })
                                            .addOnFailureListener(e -> Toast.makeText(UpdateFamilydetails.this,
                                                    "Failed to add family member: " + e.getMessage(),
                                                    Toast.LENGTH_SHORT).show());
                                    return;
                                }
                            }
                        }
                    }
                }
                // Phone number not found in the database
                Toast.makeText(UpdateFamilydetails.this,
                        "Phone number not found in the database. Please register to continue.",
                        Toast.LENGTH_SHORT).show();
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {
                // Handle errors
                Toast.makeText(UpdateFamilydetails.this,
                        "Failed to read database: " + databaseError.getMessage(), Toast.LENGTH_SHORT).show();
            }
        });
    }

    private void clearFields() {
        editTextFamilyMemberName.setText("");
        editTextAadharNumber.setText("");
        editTextAge.setText("");
    }
}
