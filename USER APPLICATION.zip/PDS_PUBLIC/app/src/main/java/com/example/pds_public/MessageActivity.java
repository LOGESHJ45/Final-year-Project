package com.example.pds_public;

import android.os.Bundle;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

public class MessageActivity extends AppCompatActivity {

    private TextView textViewMessage;
    private DatabaseReference messageRef;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_message);

        textViewMessage = findViewById(R.id.messageTextView);

        // Initialize Firebase database reference
        messageRef = FirebaseDatabase.getInstance().getReference().child("ShopDetails").child("shop1").child("streetdetails").child("street2").child("message");

        // Retrieve message from the database
        fetchMessage();
    }

    private void fetchMessage() {
        messageRef.addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                if (dataSnapshot.exists()) {
                    String message = dataSnapshot.child("message").getValue(String.class);
                    // Set the message to TextView
                    textViewMessage.setText(message);
                } else {
                    // If message does not exist, display a default message
                    textViewMessage.setText("No message found");
                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {
                // Handle errors
                textViewMessage.setText("Failed to read message: " + databaseError.getMessage());
            }
        });
    }
}
