package com.example.pds_public;

import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.os.Handler;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.ProgressBar;
import android.widget.RelativeLayout;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.cardview.widget.CardView;
import androidx.core.content.ContextCompat;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

public class UserHomePage extends AppCompatActivity {
    private RelativeLayout progressLayout;
    private ProgressBar progressBar;
    private TextView textView5;
    private TextView textView6;
    private TextView textView10;
    private TextView textView11;
    private TextView textView12;
    private DatabaseReference shopDetailsRef;
    private CardView cardViewLivestock;
    private CardView cardViewQuery;
    private CardView cardViewComplaint;
    private CardView cardViewMessage;
    private SharedPreferences sharedPreferences;
    private DatabaseReference messageRef;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_user_home_page);

        // Initialize progress bar and layout
        progressLayout = findViewById(R.id.progressLayout);
        progressBar = findViewById(R.id.progressBar);

        // Initialize other views
        textView5 = findViewById(R.id.textView5);
        textView6 = findViewById(R.id.textView6);
        textView10 = findViewById(R.id.textView10);
        textView11 = findViewById(R.id.textView11);
        textView12 = findViewById(R.id.textView12);
        cardViewLivestock = findViewById(R.id.cardViewLivestock);
        cardViewQuery = findViewById(R.id.cardViewQuery);
        cardViewComplaint = findViewById(R.id.cardViewComplaint);
        cardViewMessage = findViewById(R.id.cardViewmessage);
        ImageButton refreshIcon = findViewById(R.id.refreshIcon);
        ImageButton messageIcon = findViewById(R.id.messageIcon);
        ImageButton deleteDataButton = findViewById(R.id.deletedata);
        ImageButton logoutButton = findViewById(R.id.logout); // Added logout button

        // Initialize Firebase database reference
        shopDetailsRef = FirebaseDatabase.getInstance().getReference().child("ShopDetails");
        messageRef = FirebaseDatabase.getInstance().getReference().child("ShopDetails").child("shop1").child("streetdetails").child("street2").child("message");

        // Initialize shared preferences
        sharedPreferences = getSharedPreferences("MyPrefs", Context.MODE_PRIVATE);

        // Retrieve phone number passed from UserLogin activity
        String phoneNumber = getIntent().getStringExtra("phoneNumber");

        // Fetch SHOP_STATUS and shop number based on phone number
        fetchShopDetails(phoneNumber);

        // Set onClickListener for Update Family button
        Button buttonUpdateFamily = findViewById(R.id.buttonupdate);
        buttonUpdateFamily.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Navigate to UpdateFamilyDetails activity
                Intent intent = new Intent(UserHomePage.this, UpdateFamilydetails.class);
                startActivity(intent);
            }
        });

        // Set onClickListener for Livestock navigation button
        cardViewLivestock.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Navigate to Livestock activity
                Intent intent = new Intent(UserHomePage.this, livestock.class);
                startActivity(intent);
            }
        });

        // Set onClickListener for Query navigation button
        cardViewQuery.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Navigate to Query activity
                Intent intent = new Intent(UserHomePage.this, query.class);
                startActivity(intent);
            }
        });

        // Set onClickListener for Complaint navigation button
        cardViewComplaint.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Navigate to Complaint activity
                Intent intent = new Intent(UserHomePage.this, TrackComplaints.class);
                startActivity(intent);
            }
        });

        // Set onClickListener for Message navigation button
        cardViewMessage.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Navigate to Complaint activity
                Intent intent = new Intent(UserHomePage.this, UserComplaints.class);
                startActivity(intent);
            }
        });

        // Set OnClickListener for refreshIcon
        refreshIcon.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Show progress bar
                showProgressBar();

                // Perform refresh operation
                refreshData();
            }
        });

        // Set OnClickListener for messageIcon
        messageIcon.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Show custom dialog with message text
                showCustomDialog();
            }
        });

        // Set OnClickListener for deleteDataButton
        deleteDataButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Move to another page (Replace this with your desired action)
                // For demonstration purposes, let's move to AnotherActivity
                Intent intent = new Intent(UserHomePage.this, RemoveUser.class);
                startActivity(intent);
            }
        });

        // Set OnClickListener for logoutButton
        logoutButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Move to UserLoginPage (Logout action)
                Intent intent = new Intent(UserHomePage.this, UserLogin.class);
                startActivity(intent);
                finish(); // Finish the current activity
            }
        });

        refreshIcon.bringToFront();
        messageIcon.bringToFront();
    }

    private void fetchShopDetails(String phoneNumber) {
        shopDetailsRef.addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                for (DataSnapshot shopSnapshot : dataSnapshot.getChildren()) {
                    for (DataSnapshot streetSnapshot : shopSnapshot.child("streetdetails").getChildren()) {
                        for (DataSnapshot phoneNumberSnapshot : streetSnapshot.getChildren()) {
                            String number = phoneNumberSnapshot.getKey();
                            if (number != null && number.equals(phoneNumber)) {
                                // Phone number found, fetch SHOP_STATUS and shop number
                                String shopStatus = shopSnapshot.child("SHOP_STATUS").getValue(String.class);
                                String shopNumber = shopSnapshot.child("shopNumber").getValue(String.class);

                                // Save shop number in shared preferences
                                SharedPreferences.Editor editor = sharedPreferences.edit();
                                editor.putString("shopNumber", shopNumber);
                                editor.apply();

                                // Update UI with SHOP_STATUS and shop number
                                textView5.setText(shopStatus);
                                textView6.setText(shopNumber);
                                int backgroundColor = shopStatus.equals("Shop is closed") ?
                                        ContextCompat.getColor(getApplicationContext(), R.color.red) :
                                        ContextCompat.getColor(getApplicationContext(), R.color.green);
                                ((CardView) textView5.getParent()).setCardBackgroundColor(backgroundColor);

                                // Fetch familyHeadName, smartCardNumber, and address
                                String familyHeadName = phoneNumberSnapshot.child("familyHeadName").getValue(String.class);
                                String smartCardNumber = phoneNumberSnapshot.child("smartCardNumber").getValue(String.class);
                                String address = phoneNumberSnapshot.child("address").getValue(String.class);

                                // Update textView10, textView11, and textView12
                                textView10.setText(familyHeadName);
                                textView11.setText(smartCardNumber);
                                textView12.setText(address);

                                return;
                            }
                        }
                    }
                }
                // If phone number not found or details not found, display a message
                textView5.setText("Details not found for this phone number");
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {
                // Handle errors
                textView5.setText("Failed to read database: " + databaseError.getMessage());
            }
        });
    }

    private void showProgressBar() {
        progressLayout.setVisibility(View.VISIBLE);
    }

    private void hideProgressBar() {
        progressLayout.setVisibility(View.GONE);
    }

    private void refreshData() {
        // Simulate a refresh operation (replace with your actual refresh logic)
        recreate();

        // For demonstration, delay hiding the progress bar by 2 seconds
        new Handler().postDelayed(new Runnable() {
            @Override
            public void run() {
                // Hide progress bar
                hideProgressBar();

                // Update your UI or perform any other post-refresh tasks
            }
        }, 2000);
    }

    private void showCustomDialog() {
        AlertDialog.Builder builder = new AlertDialog.Builder(UserHomePage.this);
        LayoutInflater inflater = getLayoutInflater();
        View dialogView = inflater.inflate(R.layout.dialog_message, null);

        // Find the TextView for displaying the message
        TextView dialogMessageTextView = dialogView.findViewById(R.id.dialogMessageTextView);

        // Set the message
        messageRef.addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                if (dataSnapshot.exists()) {
                    String message = dataSnapshot.child("message").getValue(String.class);
                    dialogMessageTextView.setText(message);
                } else {
                    dialogMessageTextView.setText("No message found");
                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {
                dialogMessageTextView.setText("Failed to read message: " + databaseError.getMessage());
            }
        });

        // Set the custom view for the dialog
        builder.setView(dialogView);

        // Create the dialog
        AlertDialog dialog = builder.create();

        // Show the dialog
        dialog.show();

        // Adjust dialog window attributes for a better appearance
        Window window = dialog.getWindow();
        WindowManager.LayoutParams layoutParams = window.getAttributes();
        layoutParams.gravity = Gravity.CENTER; // Center the dialog
        window.setAttributes(layoutParams);
    }
}
