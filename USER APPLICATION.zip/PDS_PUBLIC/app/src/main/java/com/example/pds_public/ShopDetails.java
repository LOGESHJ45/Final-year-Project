package com.example.pds_public;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.widget.Switch;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

public class ShopDetails extends AppCompatActivity {

    private TextView textView1, textView2, textView3, textView4;
    private Switch switchStatus;
    private DatabaseReference databaseReference;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_shop_details);

        // Initialize Firebase Database
        databaseReference = FirebaseDatabase.getInstance().getReference();

        // Initialize UI components
        textView1 = findViewById(R.id.textView2);
        textView2 = findViewById(R.id.textView4);
        textView3 = findViewById(R.id.textView6);
        //textView4 = findViewById(R.id.textView8);
        switchStatus = findViewById(R.id.switch1);

        fetchDataFromFirebase();

        // Set an OnCheckedChangeListener for the switch
        switchStatus.setOnCheckedChangeListener((buttonView, isChecked) -> {
            // Update shop status in Firebase based on switch state
            updateShopStatus(isChecked);
        });
    }

    private void fetchDataFromFirebase() {
        // Retrieve user email from SharedPreferences
        SharedPreferences preferences = getSharedPreferences("User", MODE_PRIVATE);
        String userEmail = preferences.getString("userEmail", "");

        if (!userEmail.isEmpty()) {
            // Continue with the rest of the logic
            // Find the user node based on the email
            databaseReference.child("users")
                    .orderByChild("email")
                    .equalTo(userEmail)
                    .limitToFirst(1)
                    .addListenerForSingleValueEvent(new ValueEventListener() {
                        @Override
                        public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                            if (dataSnapshot.exists()) {
                                // Get the user node
                                DataSnapshot userSnapshot = dataSnapshot.getChildren().iterator().next();

                                // Get user details
                                String userName = userSnapshot.child("name").getValue(String.class);

                                // Check if user details exist in ShopDetails
                                checkAndDisplayShopDetails(userName);
                            } else {
                                // User not found
                                // Handle accordingly (e.g., display an error message)
                                Toast.makeText(ShopDetails.this, "User not found", Toast.LENGTH_SHORT).show();
                            }
                        }

                        @Override
                        public void onCancelled(@NonNull DatabaseError databaseError) {
                            // Handle database error
                            Toast.makeText(ShopDetails.this, "Database error: " + databaseError.getMessage(), Toast.LENGTH_SHORT).show();
                        }
                    });
        } else {
            // Handle the case where userEmail is not available
            Toast.makeText(this, "User email not available", Toast.LENGTH_SHORT).show();
        }
    }

    private void checkAndDisplayShopDetails(final String userName) {
        // Check if the user details exist in ShopDetails
        databaseReference.child("ShopDetails")
                .orderByChild("shopNumber")
                .equalTo(userName)
                .limitToFirst(1)
                .addListenerForSingleValueEvent(new ValueEventListener() {
                    @Override
                    public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                        if (dataSnapshot.exists()) {
                            // Get the ShopDetails node
                            DataSnapshot shopDetailsSnapshot = dataSnapshot.getChildren().iterator().next();

                            // Get shop details
                            String district = shopDetailsSnapshot.child("DISTRICT").getValue(String.class);
                            String shopName = shopDetailsSnapshot.child("SHOPNAME").getValue(String.class);
                            String taluk = shopDetailsSnapshot.child("TALUK").getValue(String.class);

                            // Display the data in TextViews
                            textView1.setText(userName);
                            textView2.setText(district);
                            textView3.setText(taluk);
                            //textView4.setText(taluk);

                            // Check shop status and set switch accordingly
                            String shopStatus = shopDetailsSnapshot.child("SHOP_STATUS").getValue(String.class);
                            if (shopStatus != null && shopStatus.equals("Shop is open")) {
                                switchStatus.setChecked(true);
                            } else {
                                switchStatus.setChecked(false);
                            }
                        } else {
                            // User details not found in ShopDetails
                            // Handle accordingly (e.g., display an error message)
                            Toast.makeText(ShopDetails.this, "Shop details not found", Toast.LENGTH_SHORT).show();
                        }
                    }

                    @Override
                    public void onCancelled(@NonNull DatabaseError databaseError) {
                        // Handle database error
                        Toast.makeText(ShopDetails.this, "Database error: " + databaseError.getMessage(), Toast.LENGTH_SHORT).show();
                    }
                });
    }

    private void updateShopStatus(boolean isOpen) {
        // Retrieve user email from SharedPreferences
        SharedPreferences preferences = getSharedPreferences("User", MODE_PRIVATE);
        String userEmail = preferences.getString("userEmail", "");

        if (!userEmail.isEmpty()) {
            // Continue with the rest of the logic
            // Find the user node based on the email
            databaseReference.child("users")
                    .orderByChild("email")
                    .equalTo(userEmail)
                    .limitToFirst(1)
                    .addListenerForSingleValueEvent(new ValueEventListener() {
                        @Override
                        public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                            if (dataSnapshot.exists()) {
                                // Get the user node
                                DataSnapshot userSnapshot = dataSnapshot.getChildren().iterator().next();

                                // Get user details
                                String userName = userSnapshot.child("name").getValue(String.class);

                                // Update shop status in Firebase
                                databaseReference.child("ShopDetails")
                                        .child(userName)
                                        .child("SHOP_STATUS")
                                        .setValue(isOpen ? "Shop is open" : "Shop is closed");

                                // Display a message based on the switch state
                                Toast.makeText(ShopDetails.this,
                                        isOpen ? "Shop is open" : "Shop is closed",
                                        Toast.LENGTH_SHORT).show();
                            } else {
                                // User not found
                                // Handle accordingly (e.g., display an error message)
                                Toast.makeText(ShopDetails.this, "User not found", Toast.LENGTH_SHORT).show();
                            }
                        }

                        @Override
                        public void onCancelled(@NonNull DatabaseError databaseError) {
                            // Handle database error
                            Toast.makeText(ShopDetails.this, "Database error: " + databaseError.getMessage(), Toast.LENGTH_SHORT).show();
                        }
                    });
        } else {
            // Handle the case where userEmail is not available
            Toast.makeText(this, "User email not available", Toast.LENGTH_SHORT).show();
        }
    }
}