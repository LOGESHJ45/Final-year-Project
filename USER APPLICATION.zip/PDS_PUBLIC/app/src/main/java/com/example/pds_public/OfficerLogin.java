package com.example.pds_public;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.util.Base64;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import javax.crypto.Cipher;
import javax.crypto.SecretKey;
import javax.crypto.spec.SecretKeySpec;
import java.text.SimpleDateFormat;
import java.util.Date;

public class OfficerLogin extends AppCompatActivity {

    private EditText editTextEmail, editTextPassword;
    private Button buttonSubmit;

    private DatabaseReference mDatabase;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_officer_login);

        mDatabase = FirebaseDatabase.getInstance().getReference().child("users");

        editTextEmail = findViewById(R.id.username);
        editTextPassword = findViewById(R.id.password);
        buttonSubmit = findViewById(R.id.loginButton);

        buttonSubmit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                loginUser();
            }
        });
    }

    private void loginUser() {
        final String email = editTextEmail.getText().toString().trim();
        final String password = editTextPassword.getText().toString().trim();

        mDatabase.addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                for (DataSnapshot userSnapshot : dataSnapshot.getChildren()) {
                    UserData userData = userSnapshot.getValue(UserData.class);

                    if (userData != null && userData.getEmail().equals(email)) {
                        // Email found. Now, decrypt and compare passwords.
                        String storedEncryptedPassword = userData.getPassword();
                        String storedPassword = decryptPassword(storedEncryptedPassword, "00112233445566778899AABBCCDDEEFF");

                        if (storedPassword != null && storedPassword.equals(password)) {
                            // Passwords match. Login successful.
                            Toast.makeText(OfficerLogin.this, "Login successful", Toast.LENGTH_SHORT).show();

                            // Get current date and time
                            SimpleDateFormat dateFormat = new SimpleDateFormat("hh:mm a, MM/dd/yyyy");
                            String currentDateAndTime = dateFormat.format(new Date());

                            // Update lastLogin for the user
                            userSnapshot.getRef().child("lastLogin").setValue(currentDateAndTime);

                            // Save email in SharedPreferences
                            saveEmailInPreferences(email);

                            Intent intent = new Intent(OfficerLogin.this, OfficerHomePage.class);
                            startActivity(intent);
                            finish();
                            return;
                        }
                    }
                }

                // No matching user found
                Toast.makeText(OfficerLogin.this, "Email or password is incorrect", Toast.LENGTH_SHORT).show();
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {
                Toast.makeText(OfficerLogin.this, "Database error: " + databaseError.getMessage(), Toast.LENGTH_SHORT).show();
            }
        });
    }

    private String decryptPassword(String encryptedPassword, String key) {
        try {
            Cipher cipher = Cipher.getInstance("AES");
            SecretKey secretKey = new SecretKeySpec(hexStringToByteArray(key), "AES");
            cipher.init(Cipher.DECRYPT_MODE, secretKey);
            byte[] decryptedBytes = cipher.doFinal(Base64.decode(encryptedPassword, Base64.DEFAULT));
            return new String(decryptedBytes);
        } catch (Exception e) {
            e.printStackTrace();
            return null;
        }
    }

    private byte[] hexStringToByteArray(String hexString) {
        int len = hexString.length();
        byte[] data = new byte[len / 2];
        for (int i = 0; i < len; i += 2) {
            data[i / 2] = (byte) ((Character.digit(hexString.charAt(i), 16) << 4)
                    + Character.digit(hexString.charAt(i + 1), 16));
        }
        return data;
    }

    private void saveEmailInPreferences(String email) {
        SharedPreferences preferences = getSharedPreferences("User", MODE_PRIVATE);
        SharedPreferences.Editor editor = preferences.edit();
        editor.putString("userEmail", email);
        editor.apply();
    }
}
