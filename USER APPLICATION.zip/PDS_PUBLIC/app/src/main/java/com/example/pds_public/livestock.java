package com.example.pds_public;

import android.content.Context;
import android.content.SharedPreferences;
import android.graphics.Typeface;
import android.os.Bundle;
import android.view.Gravity;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

public class livestock extends AppCompatActivity {

    private DatabaseReference databaseReference;
    private SharedPreferences sharedPreferences;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_livestock);

        // Initialize Firebase Database
        databaseReference = FirebaseDatabase.getInstance().getReference();

        // Initialize shared preferences
        sharedPreferences = getSharedPreferences("MyPrefs", Context.MODE_PRIVATE);

        // Fetch and display data
        fetchDataFromFirebase();
    }

    private void fetchDataFromFirebase() {
        String shopNumber = sharedPreferences.getString("shopNumber", "");

        if (!shopNumber.isEmpty()) {
            // Fetch data from Firebase based on Shop Number
            databaseReference.child("ShopDetails").child(shopNumber)
                    .addListenerForSingleValueEvent(new ValueEventListener() {
                        @Override
                        public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                            if (dataSnapshot.exists()) {
                                // Get the ShopDetails node
                                DataSnapshot shopDetailsSnapshot = dataSnapshot;

                                // Display the data in TextViews
                                //addContentToScrollView("Shop Number", shopDetailsSnapshot.child("shopNumber").getValue(String.class));
                                addContentToScrollView("District", shopDetailsSnapshot.child("DISTRICT").getValue(String.class));
                               // addContentToScrollView("Shop Name", shopDetailsSnapshot.child("SHOPNAME     :").getValue(String.class));
                                addContentToScrollView("Taluk", shopDetailsSnapshot.child("TALUK").getValue(String.class));
                                addContentToScrollView("Shop Status", shopDetailsSnapshot.child("SHOP_STATUS").getValue(String.class));

                                // Exclude "streetdetails" node from displaying
                                for (DataSnapshot contentSnapshot : shopDetailsSnapshot.getChildren()) {
                                    String key = contentSnapshot.getKey();
                                    if (!key.equals("DISTRICT") && !key.equals("SHOPNAME     :") && !key.equals("TALUK")
                                            && !key.equals("SHOP_STATUS") && !key.equals("shopNumber") && !key.equals("streetdetails")) {
                                        String value = contentSnapshot.getValue(String.class);
                                        addContentToScrollView(key, value);
                                    }
                                }
                            } else {
                                // Shop details not found
                                // Handle accordingly (e.g., display an error message)
                                Toast.makeText(livestock.this, "Shop details not found", Toast.LENGTH_SHORT).show();
                            }
                        }

                        @Override
                        public void onCancelled(@NonNull DatabaseError databaseError) {
                            // Handle database error
                            Toast.makeText(livestock.this, "Database error: " + databaseError.getMessage(), Toast.LENGTH_SHORT).show();
                        }
                    });
        } else {
            // Shop Number not available in shared preferences
            // Handle accordingly (e.g., display an error message)
            Toast.makeText(this, "Shop Number not available", Toast.LENGTH_SHORT).show();
        }
    }


    private void addContentToScrollView(String label, String value) {
        LinearLayout linearLayout = new LinearLayout(this);
        linearLayout.setLayoutParams(new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT));
        linearLayout.setOrientation(LinearLayout.HORIZONTAL);

        // Adjusted layout parameters for TextViews
        LinearLayout.LayoutParams textViewParams = new LinearLayout.LayoutParams(
                0,
                LinearLayout.LayoutParams.WRAP_CONTENT,
                1);

        // Add margin between label and value TextViews
        textViewParams.setMargins(0, 100, 16, 0); // You can adjust the right margin as needed

        TextView labelTextView = new TextView(this);
        labelTextView.setLayoutParams(textViewParams);
        labelTextView.setText(label);
        labelTextView.setTextSize(18);
        labelTextView.setTypeface(null, Typeface.BOLD); // Set the text to bold
        labelTextView.setGravity(Gravity.CENTER_VERTICAL | Gravity.START);

        TextView valueTextView = new TextView(this);
        valueTextView.setLayoutParams(textViewParams);
        valueTextView.setText(value);
        valueTextView.setTextSize(18);
        valueTextView.setGravity(Gravity.CENTER_VERTICAL | Gravity.START);

        linearLayout.addView(labelTextView);
        linearLayout.addView(valueTextView);

        LinearLayout scrollableSection = findViewById(R.id.scrollableSection);
        scrollableSection.addView(linearLayout);
    }
}