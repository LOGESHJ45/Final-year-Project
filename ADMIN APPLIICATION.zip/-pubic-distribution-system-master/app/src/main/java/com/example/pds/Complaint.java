package com.example.pds;

public class Complaint {
    private String tokenNumber;
    private String subject;
    private String body;
    private String senderEmail;
    private String phoneNumber;
    private String recipientEmail;
    private String recipientType;
    private String status;
    private String additionalInfo;
    private String time;

    public Complaint(String tokenNumber, String subject, String body, String senderEmail, String phoneNumber, String recipientEmail, String recipientType, String status, String additionalInfo, String time) {
        this.tokenNumber = tokenNumber;
        this.subject = subject;
        this.body = body;
        this.senderEmail = senderEmail;
        this.phoneNumber = phoneNumber;
        this.recipientEmail = recipientEmail;
        this.recipientType = recipientType;
        this.status = status;
        this.additionalInfo = additionalInfo;
        this.time = time;
    }

    public Complaint(String tokenNumber, String subject, String body, String recipientEmail, String recipientType, String status, String time) {
        this.tokenNumber = tokenNumber;
        this.subject = subject;
        this.body = body;
        this.recipientEmail = recipientEmail;
        this.recipientType = recipientType;
        this.status = status;
        this.time = time;
    }




    public Complaint() {
        // Default constructor required for Firebase
    }

    public String getTokenNumber() {
        return tokenNumber;
    }

    public void setTokenNumber(String tokenNumber) {
        this.tokenNumber = tokenNumber;
    }

    public String getSubject() {
        return subject;
    }

    public void setSubject(String subject) {
        this.subject = subject;
    }

    public String getBody() {
        return body;
    }

    public void setBody(String body) {
        this.body = body;
    }

    public String getSenderEmail() {
        return senderEmail;
    }

    public void setSenderEmail(String senderEmail) {
        this.senderEmail = senderEmail;
    }

    public String getPhoneNumber() {
        return phoneNumber;
    }

    public void setPhoneNumber(String phoneNumber) {
        this.phoneNumber = phoneNumber;
    }

    public String getRecipientEmail() {
        return recipientEmail;
    }

    public void setRecipientEmail(String recipientEmail) {
        this.recipientEmail = recipientEmail;
    }

    public String getRecipientType() {
        return recipientType;
    }

    public void setRecipientType(String recipientType) {
        this.recipientType = recipientType;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public String getAdditionalInfo() {
        return additionalInfo;
    }

    public void setAdditionalInfo(String additionalInfo) {
        this.additionalInfo = additionalInfo;
    }

    public String getTime() {
        return time;
    }

    public void setTime(String time) {
        this.time = time;
    }
}
