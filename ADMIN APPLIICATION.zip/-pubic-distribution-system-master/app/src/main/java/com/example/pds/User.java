package com.example.pds;
public class User {
    private String email;
    private String password;
    private String name;
    private String status;
    private String lastLogin; // Change lastSeen to lastLogin

    // Required default constructor for Firebase
    public User() {
    }

    public User(String email, String password, String name, String status, String lastLogin) {
        this.email = email;
        this.password = password;
        this.name = name;
        this.status = status;
        this.lastLogin = lastLogin; // Update lastSeen to lastLogin
    }

    public String getEmail() {
        return email;
    }

    public String getPassword() {
        return password;
    }

    public String getName() {
        return name;
    }

    public String getStatus() {
        return status;
    }

    public String getLastLogin() {
        return lastLogin; // Change getLastSeen() to getLastLogin()
    }
}
