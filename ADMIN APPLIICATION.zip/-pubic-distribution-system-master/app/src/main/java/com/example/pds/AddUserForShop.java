package com.example.pds;

import android.os.Bundle;
import android.text.InputFilter;
import android.util.Base64;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import javax.crypto.Cipher;
import javax.crypto.spec.SecretKeySpec;
import javax.crypto.SecretKey;

public class AddUserForShop extends AppCompatActivity {

    private EditText emailEditText, passwordEditText, nameEditText;
    private Button addButton;

    private DatabaseReference mDatabase;

    // Replace this key with your own 128-bit AES key
    private static final String AES_KEY = "00112233445566778899AABBCCDDEEFF";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_user_for_shop);

        // Initialize Firebase Realtime Database
        mDatabase = FirebaseDatabase.getInstance().getReference();

        // Initialize UI elements
        emailEditText = findViewById(R.id.editTextEmail);
        passwordEditText = findViewById(R.id.editTextPassword);
        nameEditText = findViewById(R.id.editTextshopName);
        addButton = findViewById(R.id.button);

        // Set the maximum number of characters to 6 for the password EditText
        int maxLength = 6;
        passwordEditText.setFilters(new InputFilter[]{new InputFilter.LengthFilter(maxLength)});

        addButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                saveUserDetails();
            }
        });
    }

    private void saveUserDetails() {
        String email = emailEditText.getText().toString().trim();
        String password = passwordEditText.getText().toString().trim();
        String name = nameEditText.getText().toString().trim();

        // Encrypt the password using AES
        String encryptedPassword = encryptPassword(password, AES_KEY);

        // Save user details to Firebase Realtime Database under the "users" node
        String userId = mDatabase.child("users").push().getKey(); // Generate a unique key for the user
        DatabaseReference userRef = mDatabase.child("users").child(userId);
        userRef.child("email").setValue(email);
        userRef.child("password").setValue(encryptedPassword);
        userRef.child("name").setValue(name);

        // Add "Last Login" label and set the value to "yet to login"
        userRef.child("lastLogin").setValue("yet to login");

        // Add "status" label and set the value to "active"
        userRef.child("status").setValue("active");

        // Create a subnode with the name entered by the admin under "ShopDetails"
        DatabaseReference shopDetailsRef = mDatabase.child("ShopDetails");
        Toast.makeText(AddUserForShop.this, "Data saved successfully.", Toast.LENGTH_SHORT).show();
    }

    private String encryptPassword(String password, String key) {
        try {
            Cipher cipher = Cipher.getInstance("AES");
            SecretKey secretKey = new SecretKeySpec(hexStringToByteArray(key), "AES");
            cipher.init(Cipher.ENCRYPT_MODE, secretKey);
            byte[] encryptedBytes = cipher.doFinal(password.getBytes());
            return Base64.encodeToString(encryptedBytes, Base64.DEFAULT);
        } catch (Exception e) {
            e.printStackTrace();
            return null;
        }
    }

    private byte[] hexStringToByteArray(String hexString) {
        int len = hexString.length();
        byte[] data = new byte[len / 2];
        for (int i = 0; i < len; i += 2) {
            data[i / 2] = (byte) ((Character.digit(hexString.charAt(i), 16) << 4)
                    + Character.digit(hexString.charAt(i + 1), 16));
        }
        return data;
    }
}
