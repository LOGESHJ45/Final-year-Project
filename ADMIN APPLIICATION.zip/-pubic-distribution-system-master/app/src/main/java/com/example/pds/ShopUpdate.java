package com.example.pds;

import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class ShopUpdate extends AppCompatActivity {

    private Spinner spinnerDistrict, spinnerTaluk;
    private EditText editTextShopNumber, editTextShopName;
    private Button buttonSubmit;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_shop_update);

        spinnerDistrict = findViewById(R.id.spinnerDistrict);
        spinnerTaluk = findViewById(R.id.spinnerTaluk);
        editTextShopNumber = findViewById(R.id.editTextShopNumber);
        editTextShopName = findViewById(R.id.editTextShopName);
        buttonSubmit = findViewById(R.id.buttonSubmit);

        DatabaseReference districtRef = FirebaseDatabase.getInstance().getReference().child("Districts");

        districtRef.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                List<String> districts = new ArrayList<>();
                for (DataSnapshot districtSnapshot : dataSnapshot.getChildren()) {
                    String district = districtSnapshot.getKey();
                    districts.add(district);
                }

                ArrayAdapter<String> districtAdapter = new ArrayAdapter<>(ShopUpdate.this, android.R.layout.simple_spinner_item, districts);
                districtAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
                spinnerDistrict.setAdapter(districtAdapter);
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {
                Log.e("Firebase", "Error fetching districts: " + databaseError.getMessage());
            }
        });

        spinnerDistrict.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parentView, View selectedItemView, int position, long id) {
                String selectedDistrict = parentView.getItemAtPosition(position).toString();
                DatabaseReference talukRef = districtRef.child(selectedDistrict).child("Taluk");

                talukRef.addValueEventListener(new ValueEventListener() {
                    @Override
                    public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                        List<String> taluks = new ArrayList<>();
                        for (DataSnapshot talukSnapshot : dataSnapshot.getChildren()) {
                            String taluk = talukSnapshot.getKey();
                            taluks.add(taluk);
                        }

                        ArrayAdapter<String> talukAdapter = new ArrayAdapter<>(ShopUpdate.this, android.R.layout.simple_spinner_item, taluks);
                        talukAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
                        spinnerTaluk.setAdapter(talukAdapter);
                    }

                    @Override
                    public void onCancelled(@NonNull DatabaseError databaseError) {
                        Log.e("Firebase", "Error fetching taluks: " + databaseError.getMessage());
                    }
                });
            }

            @Override
            public void onNothingSelected(AdapterView<?> parentView) {
                // Do nothing
            }
        });

        buttonSubmit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String selectedDistrict = spinnerDistrict.getSelectedItem().toString();
                String selectedTaluk = spinnerTaluk.getSelectedItem().toString();
                String shopNumber = editTextShopNumber.getText().toString();
                String shopName = editTextShopName.getText().toString();

                DatabaseReference shopRef = FirebaseDatabase.getInstance().getReference().child("ShopDetails").child(shopNumber);

                Map<String, Object> shopDetails = new HashMap<>();
                shopDetails.put("DISTRICT", selectedDistrict);
                shopDetails.put("TALUK", selectedTaluk);
                shopDetails.put("shopNumber", shopNumber);
                shopDetails.put("SHOPNAME", shopName);

                shopRef.setValue(shopDetails)
                        .addOnSuccessListener(new OnSuccessListener<Void>() {
                            @Override
                            public void onSuccess(Void aVoid) {
                                Toast.makeText(ShopUpdate.this, "Shop details added successfully", Toast.LENGTH_SHORT).show();
                            }
                        })
                        .addOnFailureListener(new OnFailureListener() {
                            @Override
                            public void onFailure(@NonNull Exception e) {
                                Log.e("Firebase", "Error adding shop details: " + e.getMessage());
                                Toast.makeText(ShopUpdate.this, "Failed to add shop details", Toast.LENGTH_SHORT).show();
                            }
                        });
            }
        });
    }
    }