package com.example.pds;

import android.os.Bundle;
import android.widget.Toast;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import com.google.firebase.database.*;
import java.util.ArrayList;
import java.util.List;

public class MainActivity5 extends AppCompatActivity {

    private ComplaintAdapter complaintAdapter;
    private DatabaseReference mDatabase;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main5);

        RecyclerView recyclerViewComplaints = findViewById(R.id.recyclerViewComplaints);
        mDatabase = FirebaseDatabase.getInstance().getReference().child("complaints");

        // Initialize RecyclerView with an empty list
        List<Complaint> complaintList = new ArrayList<>();
        complaintAdapter = new ComplaintAdapter(complaintList, this);

        recyclerViewComplaints.setLayoutManager(new LinearLayoutManager(this));
        recyclerViewComplaints.setAdapter(complaintAdapter);

        // Load complaints from Firebase
        loadComplaints();
    }

    private void loadComplaints() {
        mDatabase.addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                List<Complaint> complaintList = new ArrayList<>();
                for (DataSnapshot snapshot : dataSnapshot.getChildren()) {
                    String token = snapshot.getKey();
                    String subject = snapshot.child("subject").getValue(String.class);
                    String body = snapshot.child("body").getValue(String.class);
                    String recipientEmail = snapshot.child("recipientEmail").getValue(String.class);
                    String recipientType = snapshot.child("recipientType").getValue(String.class);
                    String status = snapshot.child("status").getValue(String.class);
                    String time = snapshot.child("time").getValue(String.class); // Retrieve time from the database
                    Complaint complaint = new Complaint(token, subject, body, recipientEmail, recipientType, status, time); // Include time in the constructor
                    complaintList.add(complaint);
                }
                // Update the RecyclerView with complaints
                complaintAdapter.setComplaints(complaintList);
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {
                // Handle error
                Toast.makeText(MainActivity5.this, "Failed to load complaints", Toast.LENGTH_SHORT).show();
            }
        });
    }
}
