package com.example.pds;

import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import com.google.firebase.database.*;
import java.util.ArrayList;
import java.util.List;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

public class ReplyComplaints extends AppCompatActivity {

    private TextView subjectTextView;
    private TextView bodyTextView;
    private TextView recipientEmailTextView;
    private TextView recipientTypeTextView;
    private TextView statusTextView;
    private TextView senderEmailTextView;
    private TextView phoneNumberTextView;
    private Spinner statusSpinner;
    private EditText editText;

    private DatabaseReference mDatabase;
    private String token;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_reply_complaints);

        subjectTextView = findViewById(R.id.subjectTextView);
        bodyTextView = findViewById(R.id.bodyTextView);
        recipientEmailTextView = findViewById(R.id.recipientEmailTextView);
        recipientTypeTextView = findViewById(R.id.recipientTypeTextView);
        statusTextView = findViewById(R.id.statusTextView);
        senderEmailTextView = findViewById(R.id.senderEmailTextView);
        phoneNumberTextView = findViewById(R.id.phoneNumberTextView);
        statusSpinner = findViewById(R.id.statusSpinner);
        editText = findViewById(R.id.editText);

        mDatabase = FirebaseDatabase.getInstance().getReference();

        token = getIntent().getStringExtra("token");

        mDatabase.child("complaints").child(token).addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                if (dataSnapshot.exists()) {
                    Complaint complaint = dataSnapshot.getValue(Complaint.class);
                    if (complaint != null) {
                        subjectTextView.setText(complaint.getSubject());
                        bodyTextView.setText(complaint.getBody());
                        recipientEmailTextView.setText(complaint.getRecipientEmail());
                        recipientTypeTextView.setText(complaint.getRecipientType());
                        statusTextView.setText(complaint.getStatus());
                        senderEmailTextView.setText(complaint.getSenderEmail());
                        phoneNumberTextView.setText(complaint.getPhoneNumber());

                        populateSpinner(complaint.getStatus());
                    }
                } else {
                    Toast.makeText(ReplyComplaints.this, "No data found for the selected token", Toast.LENGTH_SHORT).show();
                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {
                Toast.makeText(ReplyComplaints.this, "Failed to load complaint details", Toast.LENGTH_SHORT).show();
            }
        });

        Button updateStatusButton = findViewById(R.id.updateButton);
        updateStatusButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String selectedStatus = statusSpinner.getSelectedItem().toString();
                statusTextView.setText(selectedStatus);

                // Update time
                String currentTime = getCurrentTime(); // Get current time
                mDatabase.child("complaints").child(token).child("time").setValue(currentTime); // Update time in database

                String editTextValue = editText.getText().toString().trim();
                mDatabase.child("complaints").child(token).child("additionalInfo").setValue(editTextValue);

                Toast.makeText(ReplyComplaints.this, "Status, Time, and Additional Info Updated", Toast.LENGTH_SHORT).show();
            }
        });
    }

    private void populateSpinner(String currentStatus) {
        List<String> statusOptions = new ArrayList<>();
        statusOptions.add("Complaint Registered");
        statusOptions.add("Complaint Processed");
        statusOptions.add("Action Taken");

        ArrayAdapter<String> adapter = new ArrayAdapter<>(this, android.R.layout.simple_spinner_item, statusOptions);
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        statusSpinner.setAdapter(adapter);

        if (currentStatus != null && !currentStatus.isEmpty()) {
            int selectedIndex = statusOptions.indexOf(currentStatus);
            if (selectedIndex != -1) {
                statusSpinner.setSelection(selectedIndex);
            }
        }
    }

    // Function to get current time
    private String getCurrentTime() {
        SimpleDateFormat sdf = new SimpleDateFormat("hh:mm a", Locale.getDefault());
        return sdf.format(new Date());
    }
}
