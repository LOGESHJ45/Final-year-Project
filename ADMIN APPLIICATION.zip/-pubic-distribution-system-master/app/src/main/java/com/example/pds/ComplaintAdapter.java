package com.example.pds;

import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.List;

public class ComplaintAdapter extends RecyclerView.Adapter<ComplaintAdapter.ViewHolder> {

    private List<Complaint> complaints;
    private Context context;

    public ComplaintAdapter(List<Complaint> complaints, Context context) {
        this.complaints = complaints;
        this.context = context;
    }

    public void setComplaints(List<Complaint> complaints) {
        this.complaints.clear();
        this.complaints.addAll(complaints);
        notifyDataSetChanged();
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.item_complaint, parent, false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        Complaint complaint = complaints.get(position);
        holder.tokenTextView.setText(complaint.getTokenNumber());
        holder.subjectTextView.setText(complaint.getSubject());
        holder.timeTextView.setText(complaint.getTime());

        holder.itemView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Handle item click
                Intent intent = new Intent(context, ReplyComplaints.class);
                intent.putExtra("token", complaint.getTokenNumber());
                intent.putExtra("subject", complaint.getSubject());
                context.startActivity(intent);
            }
        });
    }

    @Override
    public int getItemCount() {
        return complaints.size();
    }

    public static class ViewHolder extends RecyclerView.ViewHolder {
        public TextView tokenTextView;
        public TextView subjectTextView;
        public TextView timeTextView;

        public ViewHolder(View itemView) {
            super(itemView);
            tokenTextView = itemView.findViewById(R.id.tokenTextView);
            subjectTextView = itemView.findViewById(R.id.subjectTextView);
            timeTextView = itemView.findViewById(R.id.timeTextView);
        }
    }
}
