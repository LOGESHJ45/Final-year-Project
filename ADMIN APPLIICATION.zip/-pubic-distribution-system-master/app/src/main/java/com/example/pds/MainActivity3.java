package com.example.pds;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.Query;
import com.google.firebase.database.ValueEventListener;

public class MainActivity3 extends AppCompatActivity {

    private Button buttonRemoveUser;
    private TextView textViewResult;
    private EditText editTextUserEmail;
    private DatabaseReference databaseReference;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main3);

        buttonRemoveUser = findViewById(R.id.buttonRemoveUser);
        textViewResult = findViewById(R.id.textViewResult);
        editTextUserEmail = findViewById(R.id.editTextEmail);
        databaseReference = FirebaseDatabase.getInstance().getReference();

        buttonRemoveUser.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                onRemoveButtonClick();
            }
        });
    }

    private void onRemoveButtonClick() {
        // Get the user's email from the EditText
        final String userEmail = editTextUserEmail.getText().toString().trim();

        // Validate the email (you may want to add additional validation)
        if (userEmail.isEmpty()) {
            Toast.makeText(MainActivity3.this, "Please enter the user's email", Toast.LENGTH_SHORT).show();
            return;
        }

        // Construct the reference to the "users" node
        DatabaseReference usersRef = databaseReference.child("users");

        // Check if the email exists in the users node
        Query query = usersRef.orderByChild("email").equalTo(userEmail);
        query.addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                if (dataSnapshot.exists()) {
                    // Email found, set the status to "inactive"
                    for (DataSnapshot userSnapshot : dataSnapshot.getChildren()) {
                        userSnapshot.getRef().child("status").setValue("inactive");
                    }
                    // Display a message in the textViewResult
                    textViewResult.setText("Active status set to inactive for " + userEmail);
                } else {
                    // Email not found, display a message in the textViewResult
                    textViewResult.setText("No such email found: " + userEmail);
                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {
                // Handle database error if needed
            }
        });
    }
}
