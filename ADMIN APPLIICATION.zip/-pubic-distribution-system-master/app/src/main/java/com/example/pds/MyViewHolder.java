package com.example.pds;

import android.view.View;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

public class MyViewHolder extends RecyclerView.ViewHolder {

    TextView firstName, lastName, status, lastLogin; // Change lastSeen to lastLogin

    public MyViewHolder(@NonNull View itemView) {
        super(itemView);

        firstName = itemView.findViewById(R.id.tvfirstName);
        lastName = itemView.findViewById(R.id.tvlastName);
        status = itemView.findViewById(R.id.status);
        lastLogin = itemView.findViewById(R.id.lastseen); // Change lastSeen to lastLogin
    }

    public void bind(User user) {
        firstName.setText(user.getName());
        lastName.setText(user.getEmail());
        lastLogin.setText(user.getLastLogin()); // Change getLastSeen() to getLastLogin()
        status.setText(user.getStatus());
    }
}
